package TCPRC4;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class TransmitterRC4 extends Thread{
	private final static byte[] S = new byte[256];
    private final static byte[] T = new byte[256];
    private int keylen = 0;
    public TransmitterRC4(final byte[] key) {
        if (key.length < 1 || key.length > 256) {
            throw new IllegalArgumentException(
                    "key must be between 1 and 256 bytes");
        } else {
            keylen = key.length;
            for (int i = 0; i < 256; i++) {
                S[i] = (byte) i;
                T[i] = key[i % keylen];
            }
            int j = 0;
            byte tmp;
            for (int i = 0; i < 256; i++) {
                j = (j + S[i] + T[i]) & 0xFF;
                tmp = S[j];
                S[j] = S[i];
                S[i] = tmp;
            }
        }
        }
	public static void main (String [] args) {
		try{
			long StartTime=System.currentTimeMillis();
			byte[] key=new byte[] {1,2,3,4};
			TransmitterRC4 t1=new TransmitterRC4(key);
			DatagramSocket Transmitter= new DatagramSocket();
			int i=0;
			String message="aaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbc";
			i++;
			message+="aaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbc";
			i++;
			message+="aaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbc";
			i++;
			message+="aaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbc";
			i++;
			byte[] b=encrypt(message.getBytes());
			byte[] buf=new byte[65000];

			while(true) {
			buf=b;
			DatagramPacket packets = new DatagramPacket(buf, buf.length,InetAddress.getByName("127.0.0.1"), 3000);
			for(int j=0;j<i;j++) {
				//Assuming each there is a lost byte in 16 bytes
				//1 packet to retransmit after a 3 second notice of not receiving the acknowledgement
				//Retransmitting 1 byte takes approximately 3/16 seconds => 187.5 milliseconds
				Thread.sleep((long)187.5);
			}
			Transmitter.send(packets);
			break;
			}
			System.out.println("Packets Sent");
			System.out.println("Start time was : "+StartTime);
			Transmitter.close();
		}
		catch(Exception e) {

		}
	}
	public static byte[] encrypt(final byte[] plaintext) {
        final byte[] ciphertext = new byte[plaintext.length];
        int i = 0, j = 0, k, t;
        byte tmp;
        for (int counter = 0; counter < plaintext.length; counter++) {
            i = (i + 1) & 0xFF;
            j = (j + S[i]) & 0xFF;
            tmp = S[j];
            S[j] = S[i];
            S[i] = tmp;
            t = (S[i] + S[j]) & 0xFF;
            k = S[t];
            ciphertext[counter] = (byte) (plaintext[counter] ^ k);
        }
        return ciphertext;
    }
}
