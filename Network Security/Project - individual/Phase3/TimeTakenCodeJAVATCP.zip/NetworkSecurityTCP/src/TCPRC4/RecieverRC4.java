package TCPRC4;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;


public class RecieverRC4 {
	private final static byte[] S = new byte[256];
    private final static byte[] T = new byte[256];
    private int keylen = 0;
	public RecieverRC4(final byte[] key) {
        if (key.length < 1 || key.length > 256) {
            throw new IllegalArgumentException(
                    "key must be between 1 and 256 bytes");
        } else {
            keylen = key.length;
            for (int i = 0; i < 256; i++) {
                S[i] = (byte) i;
                T[i] = key[i % keylen];
            }
            int j = 0;
            byte tmp;
            for (int i = 0; i < 256; i++) {
                j = (j + S[i] + T[i]) & 0xFF;
                tmp = S[j];
                S[j] = S[i];
                S[i] = tmp;
            }
        }
        }
	public static void main(String[] args) throws IOException {
		byte[] key=new byte[] {1,2,3,4};
		RecieverRC4 r1=new RecieverRC4(key);
		DatagramSocket Reciever=new DatagramSocket(3000);
		System.out.println("Ready to recieve the RC4 Text..");
		System.out.println("Waiting for Packets");
		boolean running=true;
		while(running) {
			byte buf[]=new byte[65000];
			DatagramPacket packets = new DatagramPacket(buf, buf.length,InetAddress.getByName("127.0.0.1"),3000);
			Reciever.receive(packets);
			byte[] data = new byte[packets.getLength()];
		    System.arraycopy(packets.getData(), packets.getOffset(), data, 0, packets.getLength());
		    String s=new String(decrypt(data));
		    System.out.println();
		    System.out.println(s);
			break;
		}
		Reciever.close();
		long endTime=System.currentTimeMillis();
		System.out.println("End Time is :"+endTime);
	}
	  public static byte[] encrypt(final byte[] plaintext) {
		    final byte[] ciphertext = new byte[plaintext.length];
		    int i = 0, j = 0, k, t;
		    byte tmp;
		    for (int counter = 0; counter < plaintext.length; counter++) {
		        i = (i + 1) & 0xFF;
		        j = (j + S[i]) & 0xFF;
		        tmp = S[j];
		        S[j] = S[i];
		        S[i] = tmp;
		        t = (S[i] + S[j]) & 0xFF;
		        k = S[t];
		        ciphertext[counter] = (byte) (plaintext[counter] ^ k);
		    }
		    return ciphertext;
		}
		public static byte[] decrypt(final byte[] ciphertext) {
		    return encrypt(ciphertext);
		}
}
