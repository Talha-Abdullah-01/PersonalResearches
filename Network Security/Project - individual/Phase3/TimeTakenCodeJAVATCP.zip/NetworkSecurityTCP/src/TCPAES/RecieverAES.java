package TCPAES;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class RecieverAES {
	 private static SecretKeySpec secretKey;
	 private static byte[] originalkey;
	 public static void main(String [] args) throws IOException {
		 RecieverAES r=new RecieverAES();
		 final String secretKey = "ssshhhhhhhhhhh!!!!";
		 DatagramSocket Reciever=new DatagramSocket(4000);
		 System.out.println("Ready to recieve the AES Text..");
		 System.out.println("Waiting for Packets");
		 ArrayList<String> decMessage=new ArrayList<>();
		 int i=0;
		 while(i<4) { //4-> varies according to packets
			 byte buf[]=new byte[65000];
				DatagramPacket packets = new DatagramPacket(buf, buf.length,InetAddress.getByName("127.0.0.1"),4000);
				Reciever.receive(packets);
				String enc=new String(packets.getData(), 0, packets.getLength());
				decMessage.add(decrypt(enc, secretKey));
				i++;
		 }
		 Reciever.close();
		 String FinalMessage="";
		 for(int z=0;z<decMessage.size();z++) {
			 System.out.println("Packet decrypted");
			 FinalMessage+=decMessage.get(z);
		 }
		 
		 long endTime=System.currentTimeMillis();
		 System.out.println("End Time is : "+endTime);
	 }
	
	 public static void setKey(final String myKey) {
		    MessageDigest sha = null;
		    try {
		    	originalkey = myKey.getBytes("UTF-8");
		    	sha = MessageDigest.getInstance("SHA-1");
		    	originalkey = sha.digest(originalkey);
		    	originalkey= Arrays.copyOf(originalkey, 16);
		      secretKey = new SecretKeySpec(originalkey, "AES");
		    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
		      e.printStackTrace();
		    }
		  }
	public static String decrypt(final String strToDecrypt, final String secret) {
	    try {
	      setKey(secret);
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
	      cipher.init(Cipher.DECRYPT_MODE, secretKey);
	      return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	    } catch (Exception e) {
	      System.out.println("Error while decrypting: " + e.toString());
	    }
	    return null;
	  }
	
}
