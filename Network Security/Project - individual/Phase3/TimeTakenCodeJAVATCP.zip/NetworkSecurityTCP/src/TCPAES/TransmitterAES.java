package TCPAES;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class TransmitterAES {
	private static SecretKeySpec secretKey;
	  private static byte[] originalkey;
	  public static void main(String [] args) throws IOException, InterruptedException {
		  long startTime=System.currentTimeMillis();
		  TransmitterAES t=new TransmitterAES();
		  System.out.println("Start Time :"+startTime);
		  final String secretKey = "ssshhhhhhhhhhh!!!!";
		  ArrayList<String> messages=new ArrayList<>();
		  DatagramSocket Transmitter= new DatagramSocket();
			String message="aaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbcaaaaaaaabbbbbbbc";
			messages.add(message); //16 bytes
			messages.add(message); //32 bytes
			messages.add(message); //48 bytes
			messages.add(message); //64 bytes
			ArrayList<String> encryptedmessages=new ArrayList<>();
			for(int j=0;j<messages.size();j++) {
				String enc=encrypt(messages.get(j), secretKey);
				encryptedmessages.add(enc);
			}
			int i=0;
			while(i<encryptedmessages.size()) {
				byte [] buf=encryptedmessages.get(i).getBytes();
				DatagramPacket packets = new DatagramPacket(buf, buf.length,InetAddress.getByName("127.0.0.1"), 4000);
				//Assuming 1 byte in the block is corrupted
				//The whole block needs to be retransmitted in order to have the correct block
				//TCP Protocol on average takes almost 3 seconds to recover the packet
				//3 seconds=3000 milliseconds
				Thread.sleep(3000);
				Transmitter.send(packets);
				System.out.println("Packets Sent");
				i++;
			}
		  Transmitter.close();
	  }
	  public static void setKey(final String myKey) {
	    MessageDigest sha = null;
	    try {
	    	originalkey = myKey.getBytes("UTF-8");
	    	sha = MessageDigest.getInstance("SHA-1");
	    	originalkey = sha.digest(originalkey);
	    	originalkey= Arrays.copyOf(originalkey, 16);
	      secretKey = new SecretKeySpec(originalkey, "AES");
	    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
	      e.printStackTrace();
	    }
	  }

	  public static String encrypt(final String strToEncrypt, final String secret) {
	    try {
	      setKey(secret);
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	      cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	      return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
	    } catch (Exception e) {
	      System.out.println("Error while encrypting: " + e.toString());
	    }
	    return null;
	  }
	  
}
