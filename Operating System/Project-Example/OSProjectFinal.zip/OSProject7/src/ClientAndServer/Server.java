package ClientAndServer;

import java.net.*;
import java.io.*;
import java.util.*;

public class Server extends Thread {
	ServerSocket server;
	ServerSocket multiplicationPort;
	ServerSocket convulationPort;
	ServerSocket minMaxPort;
	ServerSocket sortMatrixPort;
	ServerSocket sumDiagonalPort;
	
	PrintWriter to_client;
	BufferedReader from_client;
	Socket nextClient;
	static int[] ports = { 1320, 1330, 1340, 1350, 1360 };
	public Server() {
		try {
			server = new ServerSocket(1300);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.start();
	}

	public void run() {
		System.out.println("Server waiting for client on port " + server.getLocalPort());
		System.out.println("Matrix Computation Server Started");
		try {
			multiplicationPort = new ServerSocket(ports[0]);
			convulationPort = new ServerSocket(ports[1]);
			sumDiagonalPort = new ServerSocket(ports[2]);
			minMaxPort = new ServerSocket(ports[3]);
			sortMatrixPort = new ServerSocket(ports[4]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (;;) {
			try {
				nextClient = server.accept();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			MainService s = new MainService(nextClient, multiplicationPort, convulationPort, minMaxPort, sortMatrixPort, sumDiagonalPort);
			s.start();

		}
	}

	public static void main(String[] args) {
		Server s = new Server();
	}
}