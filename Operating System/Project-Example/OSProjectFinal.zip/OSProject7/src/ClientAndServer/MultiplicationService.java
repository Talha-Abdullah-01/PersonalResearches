package ClientAndServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
//https://www.programiz.com/java-programming/examples/multiply-matrix-function
public class MultiplicationService extends Thread{
	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;

	public MultiplicationService(Socket nextClient) {
		super();
		this.nextClient = nextClient;
	}
	public void run() {
		try {
				System.out.println("Multiplication service port :" + nextClient.getPort());
				to_client=new PrintWriter(nextClient.getOutputStream(),true);
				from_client=new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
				to_client.println("Enter the Number of Rows of the 1st Matrix : ");
				String rowsString=from_client.readLine();
				to_client.println("Enter the number of columns of 1st Matrix : ");
				String columnString=from_client.readLine();
				to_client.println("Enter the Number of Rows of the 2nd Matrix : ");
				String rowsString1=from_client.readLine();
				to_client.println("Enter the number of columns of 2nd Matrix : ");
				String columnString1=from_client.readLine();
				if(columnString.equals(rowsString1) && rowsString.equals(columnString1)) {
					to_client.println("Both Dimensions Match ! Success !");
					int r1=Integer.parseInt(rowsString);
					int c1=Integer.parseInt(columnString);
					int r2=Integer.parseInt(rowsString1);
					int c2=Integer.parseInt(columnString1);
					int first[][]=new int[r1][c1];
					int second[][]=new int[r2][c2];
					to_client.println("Enter the 1st Matrix Values : ");
					for (int i = 0; i < r1; i++) {
				         for (int j = 0; j < c1; j++) {
				        	to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
				        	String clientEntry=from_client.readLine();
				        	first[i][j]=Integer.parseInt(clientEntry);
				         }     
					}
					to_client.println("Enter the 2nd Matrix Values : ");
					for (int i = 0; i < r2; i++) {
				         for (int j = 0; j < c2; j++) {
				        	to_client.println("Enter the 2["+i+"]["+j+"] Value : ");
				        	String clientEntry=from_client.readLine();
				        	second[i][j]=Integer.parseInt(clientEntry);
				         }     
					}
					int[][] product = new int[r1][c2];
					for(int i = 0; i < r1; i++) {
						for (int j = 0; j < c2; j++) {
							for (int k = 0; k < c1; k++) {
					                product[i][j] += first[i][k] * second[k][j];
					                }
					            }
					    }
					to_client.println("Printing out the product of the Matrix : ");
					for(int i=0;i<r1;i++) {
						for(int j=0; j<c2;j++) {
							to_client.println(product[i][j]);
						}
					}
				}
				else {
					to_client.println("Dimensions do not match. Both matrix should have nxn=nxn dimension");
					System.exit(0);
				}
		}catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				
				if(nextClient!=null) {
					nextClient.close();
				}
				if(to_client!=null) {
					to_client.close();
				}
				if(from_client!=null) {
					from_client.close();
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
	}

}
}