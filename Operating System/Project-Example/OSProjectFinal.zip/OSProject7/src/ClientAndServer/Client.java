package ClientAndServer;

import java.net.*;
import java.io.*;

public class Client {
	public Client() {
		try {
			Socket clientconn = new Socket("localhost", 1300);
			BufferedReader from_server = new BufferedReader(new InputStreamReader(clientconn.getInputStream()));
			BufferedReader from_client = new BufferedReader(new InputStreamReader(System.in));
			PrintWriter to_server = new PrintWriter(clientconn.getOutputStream(),true);

			System.out.println("Connected with server " + clientconn.getInetAddress() + ":" + clientconn.getPort());
			String reader;
			for(int i=0;i<6;i++) {
			reader=from_server.readLine();
			System.out.println(reader);
			}
			System.out.print("Enter your choice here : ");
			String option=from_client.readLine();
			to_server.println(option);
			if(option.equals("1")) {
				Socket clientconn1=new Socket("localhost",1320);
				System.out.println("Connected with service : " +clientconn1.getInetAddress()+":"+clientconn1.getPort());
				reader=from_server.readLine();
				System.out.println(reader);
				reader=from_server.readLine();
				System.out.print(reader);
				String r1=from_client.readLine();
				to_server.println(r1);
				reader=from_server.readLine();
				System.out.print(reader);
				String r2=from_client.readLine();
				to_server.println(r2);
				reader=from_server.readLine();
				System.out.print(reader);
				String r3=from_client.readLine();
				to_server.println(r3);
				reader=from_server.readLine();
				System.out.print(reader);
				String r4=from_client.readLine();
				to_server.println(r4);
				reader=from_server.readLine();
				System.out.println(reader);
				if(reader.equals("Both Dimensions Match ! Success !")) {
					reader=from_server.readLine();
					System.out.println(reader);
					int row1=Integer.parseInt(r1);
					int column1=Integer.parseInt(r2);
					for (int i = 0; i < row1; i++) {
				         for (int j = 0; j < column1; j++) {
				        	String serverEntry=from_server.readLine();
				        	System.out.print(serverEntry);
				        	String clientEntry=from_client.readLine(); 
				        	to_server.println(clientEntry);
				         }     
					}
					reader=from_server.readLine();
					System.out.println(reader);
					int row2=Integer.parseInt(r3);
					int column2=Integer.parseInt(r4);
					for (int i = 0; i < row2; i++) {
				         for (int j = 0; j < column2; j++) {
				        	String serverEntry=from_server.readLine();
				        	System.out.print(serverEntry);
				        	String clientEntry=from_client.readLine(); 
				        	to_server.println(clientEntry);
				         }     
					}
					reader=from_server.readLine();
					System.out.println(reader);
					for(int i=0;i<row1;i++) {
						for(int j=0; j<column2;j++) {
							String s=from_server.readLine();
							int sint=Integer.parseInt(s);
							System.out.print(sint+ "\t");
						}
						System.out.println();
					}
				}
			}
			else if(option.equals("2")) {
				Socket clientconn2=new Socket("localhost",1330);
				System.out.println("Connected with service : " +clientconn2.getInetAddress()+":"+clientconn2.getPort());
				for(int i=0;i<4;i++) {
					reader=from_server.readLine();
					System.out.println(reader);
				}
				String s=from_client.readLine();
				to_server.println(s);
				if(s.equals("1") || s.equals("2")) {
				if(s.equals("1")) {
					reader=from_server.readLine();
					System.out.println(reader);
					for (int i = 0; i < 2; i++) {
				         for (int j = 0; j < 2; j++) {
				        	String serverEntry=from_server.readLine();
				        	System.out.print(serverEntry);
				        	String clientEntry=from_client.readLine(); 
				        	to_server.println(clientEntry);
				         }     
					}
				}
				else if(s.equals("2")) {
					reader=from_server.readLine();
					System.out.println(reader);
					for (int i = 0; i < 3; i++) {
				         for (int j = 0; j < 3; j++) {
				        	String serverEntry=from_server.readLine();
				        	System.out.print(serverEntry);
				        	String clientEntry=from_client.readLine(); 
				        	to_server.println(clientEntry);
				         }     
					}
				}
				for(int i=0;i<3;i++) {
					reader=from_server.readLine();
					System.out.println(reader);
				}
				String z=from_client.readLine();
				to_server.println(z);
				if(z.equals("1") || z.equals("2")) {
				if(z.equals("1")) {
					reader=from_server.readLine();
					System.out.println(reader);
					for (int i = 0; i < 8; i++) {
				         for (int j = 0; j < 8; j++) {
				        	String serverEntry=from_server.readLine();
				        	System.out.print(serverEntry);
				        	String clientEntry=from_client.readLine(); 
				        	to_server.println(clientEntry);
				         }     
					}
				}
				else if(z.equals("2")) {
					reader=from_server.readLine();
					System.out.println(reader);
					for (int i = 0; i < 16; i++) {
				         for (int j = 0; j < 16; j++) {
				        	String serverEntry=from_server.readLine();
				        	System.out.print(serverEntry);
				        	String clientEntry=from_client.readLine(); 
				        	to_server.println(clientEntry);
				         }     
					}
				}
				String w=from_server.readLine();
				int w1=Integer.parseInt(w);
				String h=from_server.readLine();
				int h1=Integer.parseInt(h);
				reader=from_server.readLine();
				System.out.println(reader);
				for (int i =0; i<w1;i++){ 
					for (int j=0; j<h1-1; j++){
						String serverOutput=from_server.readLine();
						System.out.print(serverOutput); 
						}
					System.out.println();
					} 
				}
				else {
					System.out.println("Invalid Option");
					System.exit(1);
				}
				}
				else {
				System.exit(1);
				}
			}
			else if(option.equals("3")) {
				Socket clientconn2=new Socket("localhost",1340);
				System.out.println("Connected with service : " +clientconn2.getInetAddress()+":"+clientconn2.getPort());
				reader=from_server.readLine();
				System.out.println(reader);
				String serverstatement=from_server.readLine();
				System.out.print(serverstatement);
				String clientEntrysize=from_client.readLine();
				to_server.println(clientEntrysize);
				String serverReply=from_server.readLine();
				System.out.println(serverReply);
				reader=from_server.readLine();
				System.out.println(reader);
				int size=Integer.parseInt(clientEntrysize);
				for (int i = 0; i < size; i++) {
			         for (int j = 0; j < size; j++) {
			        	String serverEntry=from_server.readLine();
			        	System.out.print(serverEntry);
			        	String clientEntry=from_client.readLine(); 
			        	to_server.println(clientEntry);
			         }     
				}
				for(int i=0;i<2;i++) {
				String y=from_server.readLine();
				System.out.println(y);
				}
			}
			else if(option.equals("4")) {	
				Socket clientconn2=new Socket("localhost",1350);
				System.out.println("Connected with service : " +clientconn2.getInetAddress()+":"+clientconn2.getPort());
				reader=from_server.readLine();
				System.out.println(reader);
				String serverstatement=from_server.readLine();
				System.out.print(serverstatement);
				String clientEntryrow=from_client.readLine();
				to_server.println(clientEntryrow);
				String serverstatement1=from_server.readLine();
				System.out.print(serverstatement1);
				String clientEntrycolumn=from_client.readLine();
				to_server.println(clientEntrycolumn);
				String serverReply=from_server.readLine();
				System.out.println(serverReply);
				reader=from_server.readLine();
				System.out.println(reader);
				int row=Integer.parseInt(clientEntryrow);
				int column=Integer.parseInt(clientEntrycolumn);
				for (int i = 0; i < row; i++) {
			         for (int j = 0; j < column; j++) {
			        	String serverEntry=from_server.readLine();
			        	System.out.print(serverEntry);
			        	String clientEntry=from_client.readLine(); 
			        	to_server.println(clientEntry);
			         }     
				}
				for(int i=0;i<2;i++) {
				reader=from_server.readLine();
				System.out.println(reader);
			
				}
			}
			else if(option.equals("5")) {
				Socket clientconn2=new Socket("localhost",1360);
				System.out.println("Connected with service : " +clientconn2.getInetAddress()+":"+clientconn2.getPort());
				reader=from_server.readLine();
				System.out.println(reader);
				String serverstatement=from_server.readLine();
				System.out.print(serverstatement);
				String clientEntryrow=from_client.readLine();
				to_server.println(clientEntryrow);
				String serverstatement1=from_server.readLine();
				System.out.print(serverstatement1);
				String clientEntrycolumn=from_client.readLine();
				to_server.println(clientEntrycolumn);
				String serverReply=from_server.readLine();
				System.out.println(serverReply);
				reader=from_server.readLine();
				System.out.println(reader);
				int row=Integer.parseInt(clientEntryrow);
				int column=Integer.parseInt(clientEntrycolumn);
				for (int i = 0; i < row; i++) {
			         for (int j = 0; j < column; j++) {
			        	String serverEntry=from_server.readLine();
			        	System.out.print(serverEntry);
			        	String clientEntry=from_client.readLine(); 
			        	to_server.println(clientEntry);
			         }     
				}
				for(int i=0;i<3;i++) {
					String s=from_server.readLine();
					System.out.println(s);
				}
				String enterHere=from_server.readLine();
				System.out.print(enterHere);
				String enterFromUser=from_client.readLine();
				to_server.println(enterFromUser);
				reader=from_server.readLine();
				System.out.println(reader);
				for(int i=0;i<row;i++) {
					for(int j=0; j<column;j++) {
						String s=from_server.readLine();
						int sint=Integer.parseInt(s);
						System.out.print(sint+ "\t");
					}
					System.out.println();
				}
			
			}
			System.out.println("-------------------TERMINATING----------------");
		} catch (IOException ioe) {
			System.out.println("Error" + ioe);
		}

	}

	public static void main(String [] args) {
	new Client();
}

}

