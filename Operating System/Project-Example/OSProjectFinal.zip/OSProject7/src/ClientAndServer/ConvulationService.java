package ClientAndServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
//https://www.chegg.com/homework-help/questions-and-answers/program-java-2d-convolution-algorithm-using-matrices-given--matrix-b-kernel-q47521694
public class ConvulationService extends Thread{
	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;

	public ConvulationService(Socket nextClient) {
		super();
		this.nextClient = nextClient;
	}
	public void run() {
		try {
				System.out.println("Convulation service port :" + nextClient.getPort());
				to_client=new PrintWriter(nextClient.getOutputStream(),true);
				from_client=new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
				to_client.println("Choose Kernel Size : ");
				to_client.println("1. 2x2 ");
				to_client.println("2. 3x3 ");
				String y=from_client.readLine();
				int [][] first;
				int iwidth = 0;
				int iheight = 0;
				int kernelh = 0; 
				int kernelw = 0; 
				int outputWidth = 0; 
				int outputHeight = 0;
				if(y.equals("1")|| y.equals("2")) {
				if(y.equals("1"))
				{
					first=new int[2][2];
					kernelh=2;
					kernelw=2;
					to_client.println("Enter the Kernel Matrix Values (2x2 Matrix): ");
					for (int i = 0; i < 2; i++) {
				         for (int j = 0; j < 2; j++) {
				        	to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
				        	String clientEntry=from_client.readLine();
				        	first[i][j]=Integer.parseInt(clientEntry);
				         }     
					}
				}
				else {
					first=new int[3][3];
					kernelh=3;
					kernelw=3;
					to_client.println("Enter the Kernel Matrix Values (3x3 Matrix): ");
					for (int i = 0; i < 3; i++) {
				         for (int j = 0; j < 3; j++) {
				        	to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
				        	String clientEntry=from_client.readLine();
				        	first[i][j]=Integer.parseInt(clientEntry);
				         }     
					}
					}
				to_client.println("Choose Matrix Size : ");
				to_client.println("1. 8x8 ");
				to_client.println("2. 16x16 ");
				String z=from_client.readLine();
				int [][] second;
				if(z.equals("1")|| z.equals("2")) {
				if(z.equals("1"))
				{
					second=new int[8][8];
					iwidth=8;
					iheight=8;
					to_client.println("Enter the Kernel Matrix Values (8x8 Matrix): ");
					for (int i = 0; i < 8; i++) {
				         for (int j = 0; j < 8; j++) {
				        	to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
				        	String clientEntry=from_client.readLine();
				        	second[i][j]=Integer.parseInt(clientEntry);
				         }     
					}
				}
				else {
					second=new int[16][16];
					iwidth=16;
					iheight=16;
					to_client.println("Enter the Kernel Matrix Values (16x16 Matrix): ");
					for (int i = 0; i < 16; i++) {
				         for (int j = 0; j < 16; j++) {
				        	to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
				        	String clientEntry=from_client.readLine();
				        	second[i][j]=Integer.parseInt(clientEntry);
				         }     
					}
					}
				outputWidth=iwidth-kernelw+1;
				to_client.println(outputWidth);
				outputHeight=iheight-kernelh+1;
				to_client.println(outputHeight);
				to_client.println("Printing the resulted convulated Matrix : ");
				int output[][]=new int[outputWidth][outputHeight];
				output = twoDConvolution(second,iwidth,iheight,first,kernelw,kernelh); 
				for (int i =0; i<outputWidth;i++){ 
					for (int j=0; j<outputHeight-1; j++){ 
						to_client.println(output[i][j] +" "+output[i][j+1]); 
						} 
					} 
				}else {
					System.exit(1);
				}
				}
				else {
					System.exit(1);
				}
		}catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(to_client!=null) {
					to_client.close();
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
		
}
	public static int onePixelConv(int [][] input, int x, int y, int [][] k, int kernelWidth, int kernelHeight){
		int output = 0; 
		for(int i=0;i<kernelWidth;++i){ 
			for(int j=0;j<kernelHeight;++j){ 
				output = output + (input[x+i][y+j] * k[i][j]); 
				} 
			} 
		return output; 
	} 
	public static int[][] twoDConvolution(int[][] input, int width, int height, int[][] kernel, int kernelWidth, int kernelHeight) 
	{ 
		int outputWidth = width - kernelWidth + 1; 
		int outputHeight = height - kernelHeight + 1; 
		int[][] output = new int[outputWidth][outputHeight]; 
		for (int i = 0; i < outputWidth; ++i) { 
			for (int j = 0; j < outputHeight; ++j) { 
				output[i][j] = 0; } } 
		for (int i = 0; i < outputWidth; ++i) { 
			for (int j = 0; j < outputHeight; ++j) { 
				output[i][j] = onePixelConv(input, i, j, kernel, kernelWidth, kernelHeight); 
				} 
			} 
		return output; 
		} 
}
