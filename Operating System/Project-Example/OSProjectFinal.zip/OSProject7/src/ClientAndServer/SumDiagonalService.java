 package ClientAndServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
//https://stackoverflow.com/questions/48330630/java-sum-all-elements-of-triangles-formed-above-and-below-main-diagonal
public class SumDiagonalService extends Thread{

	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;

	public SumDiagonalService(Socket nextClient) {
		super();
		this.nextClient = nextClient;
	}
	public void run() {
		try {
			System.out.println("SumDiagonal service port :" + nextClient.getPort());
			to_client=new PrintWriter(nextClient.getOutputStream(),true);
			from_client=new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
			to_client.println("Enter the Size of the Matrix (nxn) : ");
			String s=from_client.readLine();
			int read=Integer.parseInt(s);
			to_client.println("The Size of Matrix is : "+read+"x"+read);
			int array[][]=new int[read][read];
			to_client.println("Enter the Matrix Values : ");
			for (int i = 0; i < read; i++) {
				for (int j = 0; j < read; j++) {
					to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
					String clientEntry=from_client.readLine();
					array[i][j]=Integer.parseInt(clientEntry);
				}     
			}
			int sum=0;
		       for (int j = 1; j < read; j++) {
		              for (int i=j-1 ; i>=0 ; i--) {
		                    sum= sum + array[i][j];
		              }
		       }
		       int sumBelow=0;
		       for (int i = 1; i < read; i++) {
		              for (int j=i-1 ; j>=0 ; j--) {
		                    sumBelow= sumBelow+ array[i][j];
		              }
		       }
		       to_client.println("Sum Above is : "+sum);
		       to_client.println("Sum Below is : "+sumBelow);
		}catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(nextClient!=null) {
					nextClient.close();
				}
				if(to_client!=null) {
					to_client.close();
				}
				if(from_client!=null) {
					from_client.close();
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
}
}
