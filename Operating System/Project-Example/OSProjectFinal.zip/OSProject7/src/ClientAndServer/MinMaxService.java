package ClientAndServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
//https://www.netjstech.com/2017/11/find-maximum-and-minimum-numbers-in-matrix-java-program.html
public class MinMaxService extends Thread{
	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;

	public MinMaxService(Socket nextClient) {
		super();
		this.nextClient = nextClient;
	}
	public void run() {
		try {
			System.out.println("MinMax service port :" + nextClient.getPort());
			to_client=new PrintWriter(nextClient.getOutputStream(),true);
			from_client=new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
			to_client.println("Enter the Rows of the Matrix : ");
			String s=from_client.readLine();
			int r=Integer.parseInt(s);
			to_client.println("Enter the Columns of the Matrix : ");
			String v=from_client.readLine();
			int c=Integer.parseInt(v);
			to_client.println("The Size of Matrix is : "+r+"x"+c);
			int array[][]=new int[r][c];
			to_client.println("Enter the Matrix Values : ");
			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++) {
					to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
					String clientEntry=from_client.readLine();
					array[i][j]=Integer.parseInt(clientEntry);
				}     
			}
			int maxNum = array[0][0];
			int minNum = array[0][0];
			for (int i = 0; i < array.length; i++) {
				for (int j = 0; j < array[i].length; j++) {
					if(maxNum < array[i][j]){
						maxNum = array[i][j];
					}else if(minNum > array[i][j]){
						minNum = array[i][j];
					}
				}
				to_client.println("Maximum value in this array is : "+maxNum);
				to_client.println("Minimum value in this array is : "+minNum);
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(nextClient!=null) {
					nextClient.close();
				}
				if(to_client!=null) {
					to_client.close();
				}
				if(from_client!=null) {
					from_client.close();
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
}