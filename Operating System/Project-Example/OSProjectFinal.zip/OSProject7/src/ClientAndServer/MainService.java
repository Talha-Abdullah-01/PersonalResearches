package ClientAndServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MainService extends Thread {
	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;
	ServerSocket server;
	ServerSocket multiplicationPort;
	ServerSocket convulationPort;
	ServerSocket minMaxPort;
	ServerSocket sortMatrixPort;
	ServerSocket sumDiagonalPort;

	public MainService(Socket nextClient, ServerSocket multiplicationPort, ServerSocket convulationPort,
			ServerSocket minMaxPort, ServerSocket sortMatrixPort, ServerSocket sumDiagonalPort) {
		super();
		this.nextClient = nextClient;
		this.multiplicationPort = multiplicationPort;
		this.convulationPort = convulationPort;
		this.minMaxPort = minMaxPort;
		this.sortMatrixPort = sortMatrixPort;
		this.sumDiagonalPort = sumDiagonalPort;
	}

	public void run() {
		try {
			to_client = new PrintWriter(nextClient.getOutputStream(), true);
			from_client = new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
			// Display connection details
			System.out.println("Receiving Request From " + nextClient.getInetAddress() + ":" + nextClient.getPort());
			to_client.println("Choose any of the matrix operations : ");
			to_client.println("1. Matrix Multiplication ");
			to_client.println("2. Perform Convolution operation on a matrix");
			to_client.println("3. Sum Numbers below and above the diagonal, then compare");
			to_client.println("4. Find maximum and minimum elements in a matrix");
			to_client.println("5. Sort the matrix elements in Ascending/Descending Order");

			String clientOptionString = from_client.readLine();
			int clientOption = Integer.parseInt(clientOptionString);
			if (clientOption == 1) {
				Socket multiplicationClient = multiplicationPort.accept();
				to_client.println("Connected to Local Host Port Number : " + multiplicationClient.getLocalPort());
				MultiplicationService s1 = new MultiplicationService(nextClient);
				s1.start();
			} else if (clientOption == 2) {
				Socket ConvulationClient = convulationPort.accept();
				to_client.println("Connected to Local Host Port Number : " + ConvulationClient.getLocalPort());
				ConvulationService s2 = new ConvulationService(nextClient);
				s2.start();
			} else if (clientOption == 3) {
				Socket sumDiagonals = sumDiagonalPort.accept();
				to_client.println("Connected to Local Host Port Number : " + sumDiagonals.getLocalPort());
				SumDiagonalService s3 = new SumDiagonalService(nextClient);
				s3.start();
			} else if (clientOption == 4) {
				Socket minMaxClient = minMaxPort.accept();
				to_client.println("Connected to Local Host Port Number : " + minMaxClient.getLocalPort());
				MinMaxService s4 = new MinMaxService(nextClient);
				s4.start();
			} else if (clientOption == 5) {
				Socket sortMatrix = sortMatrixPort.accept();
				to_client.println("Connected to Local Host Port Number : " + sortMatrix.getLocalPort());
				SortMatrixService s5 = new SortMatrixService(nextClient);
				s5.start();
			} else {
				System.exit(0);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
