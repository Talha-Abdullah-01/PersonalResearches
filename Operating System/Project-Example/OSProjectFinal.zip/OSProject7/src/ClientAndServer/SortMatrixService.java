package ClientAndServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;
//https://www.geeksforgeeks.org/sort-given-matrix/
public class SortMatrixService extends Thread{
	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;

	public SortMatrixService(Socket nextClient) {
		super();
		this.nextClient = nextClient;
	}
	public void run() {
		try {
			System.out.println("SortMatrix service port :" + nextClient.getPort());
			to_client=new PrintWriter(nextClient.getOutputStream(),true);
			from_client=new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
			to_client.println("Enter the Rows of the Matrix : ");
			String s=from_client.readLine();
			int r=Integer.parseInt(s);
			to_client.println("Enter the Columns of the Matrix : ");
			String v=from_client.readLine();
			int c=Integer.parseInt(v);
			to_client.println("The Size of Matrix is : "+r+"x"+c);
			int array[][]=new int[r][c];
			int temp;
			to_client.println("Enter the Matrix Values : ");
			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++) {
					to_client.println("Enter the 1["+i+"]["+j+"] Value : ");
					String clientEntry=from_client.readLine();
					array[i][j]=Integer.parseInt(clientEntry);
				}     
			}
			to_client.println("Choose Your Option");
			to_client.println("1. Sort in Ascending Order");
			to_client.println("2. Sort in Descending Order");
			to_client.println("Enter : ");
			String userOption=from_client.readLine();
			if(userOption.equals("1")) {
						int ascended[][]=new int[r][c];
				        int temp1[] = new int[r * c];
				        int k = 0;
				        for (int i = 0; i < r; i++)
				            for (int j = 0; j < c; j++)
				                temp1[k++] = array[i][j];
				        Arrays.sort(temp1);
				        k = 0;
				        for (int i = 0; i < r; i++)
				            for (int j = 0; j < c; j++)
				            	ascended[i][j] = temp1[k++];
				  to_client.println("Printing out the Ascending ordered Matrix : ");
					for(int i=0;i<r;i++) {
						for(int j=0; j<c;j++) {
							to_client.println(ascended[i][j]);
						}
					}
			}
			else if(userOption.equals("2")) {
				int descended[][]=new int[r][c];
		        int temp1[] = new int[r * c]; 
		        int k = 0;
		        for (int i = 0; i < r; i++)
		            for (int j = 0; j < c; j++)
		                temp1[k++] = array[i][j];
		        Arrays.sort(temp1);
		        int z = r*c-1;
		        for (int i = 0; i < r; i++)
		            for (int j = 0; j < c; j++)
		            	descended[i][j] = temp1[z--];
		        to_client.println("Printing out the Descending ordered Matrix : ");
			for(int i=0;i<r;i++) {
				for(int j=0; j<c;j++) {
					to_client.println(descended[i][j]);
				}
			}
			}
			else {
				System.exit(0);
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(nextClient!=null) {
					nextClient.close();
				}
				if(to_client!=null) {
					to_client.close();
				}
				if(from_client!=null) {
					from_client.close();
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
}
}
