

public class App {

	public static void main(String[] args) {
		new App(); // this will call the constructor of App below

	}
	
	public App()
	{
		// TODO 08: create a medical glass with your own information
		
		
		// TODO 09: create a sun glass with your own information
		
		
		// TODO 10: print the full prices of the glasses above.
		
		// TODO 12: print ALL glasses information
		//			hint: what do you need to create inside MedicalGlasses and SunGlasses?
		
		
		/*
		 * TODO 14: create a Store class that has the following:
		 *  - name (String)
		 *  - ArrayList to hold medical and sun glasses (call it glassAList)
		 *
		 *	Copy the following todos inside that class:
		 
			//TODO 14a: create a constructor for the Store
			
			//TODO 14b: create an addGlass method that will add a glass to the ArrayList
			
			//TODO 17: create a method that will get either Sunglasses or MedicalGlasses given by index
			
			
			//TODO 20: make a method that will display the colors of all SUN Glasses in the store.
			//		   hint: you will need to use the getter you made in todo 19.
			
		*/
		
		
		
		// TODO 15: create a new Store and put the glasses from todo 08 and 09 in it (in position 0, and 1)
		
		
		
		// TODO 16: print all the glasses in the store.
		//			Q1: should you print medical glasses differently than sun glasses?
		
		
		// TODO 18: print only the Medical glasses in the store.
		// 			Use your work from todo 17 to access the glasses by index
		

		// TODO 21: add another new SunGlasses with a different color to your store
		
		
		// TODO 22: use your work from todo 20 to print all the colors of the SUN glasses in the store.
		
	}


}
