package glasses;

public class Glasses {

	//TODO 01: create "private" instance variables that describe all glasses
	//         start by removing the comment from the variable below
	
	// private double price;

	
	//TODO 02: create a constructor to initialize all the instance variables.

	
	//TODO 03: create a getFullPrice function that will just return the price
	// 		TODO 11c: what happens if you make this method private? protected?
	
	
	//TODO 04: create a toString method

	
}

/*
 * TODO 05: create the following sub-classes of Glasses:
 * 	- Medical Glasses
 *  - Sun Glasses
 *  
 *  Now copy the todo items to each class respectively:
 * 
 *  MedicalGlasses:
	 //TODO 06a: create instance variables that describe medical glasses.

	 
	 //TODO 06b: create a constructor to initialize the instance variables.

	 
	 //TODO 11a: Override the method getFullPrice with a new one of your own.

	 //TODO 13a: create a toString method
 * 
 * 	SunGlasses:
 	 //TODO 07a: create instance variables that describe sun glasses.
	 //			 start by adding color (String) as a "private" variable.
	 
	 //TODO 07b: create a constructor to initialize the instance variables.

	 //TODO 11b: Override the method getFullPrice with a new one of your own.
	
	 
	 //TODO 13b: create a toString method, then re-run the program, what do you see in the output?
	 // 		 Notice that you did not have to change anything to display the overridden version of toString()
	
	 //TODO 19: create a getter for the color instance variable.

 */

