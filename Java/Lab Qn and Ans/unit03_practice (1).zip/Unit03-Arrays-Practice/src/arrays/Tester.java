package arrays;

public class Tester {

	public static void main(String[] args)
	{
		
		//TODO 01: create a an array of 3 ints called "a".
		
		//TODO 02: put the values (123, 897, and 430) in it.
		
		//TODO 03: print the values inside the array 
		
		//TODO 04: create an array of 3 Persons called "persons"


		//TODO 05: put the Persons ("Ahmad Ghanim", "Fatima Jassim", "Khalid Hamad").


		//TODO 06: print the values inside the array "persons"
		//		   is there a nicer way to do it?!
		
		
		//TODO 07: Is there a "nicer" way to access array elements when indices do not matter? (when there is no need to know exact position of each element)
		// 		   Hint: use the new for-each loop to print everything in "persons"

		
		//TODO 08: print the first array "a" in one statement (no for-loop)
		
		//TODO 09: sort the first array "a" that you created

		//TODO 10: create a new array (called "b") of 10 ints with the values 88 in it.

		//TODO 11: copy the contents of array "a" into "b". Place them in third position .

		//TODO 12: what happens if we try to put the number 218 in the fourth position in array a a[3]?

		//TODO 13: what happens if we create a new array of Person objects, and then immediately set the name of the first person in the array? (try it!)
		// try it by creating a person array with of size 3, then call setfName(...) of the first person in the array. 

		
		/*
		 * ARRAYLIST EXAMPLES BELOW
		 */
		
		
		//TODO 14: create an ArrayList of 3 persons called personList.
		
		
		//TODO 15: add the persons you added in "persons" to personList, then display it
		
		
		//TODO 16: create a new person p with Name = "Jabir" "Fahad"
		
		//TODO 17: replace the second person in the list with Jabir

		
		
		//TODO 18: display all items in the array list in one line

		
		//TODO 19: fill the above personList ArrayList with p

		
		//TODO 20: print them all again

		
		// Question: what happens if you change p's first name? would that affect personList?
		// try it!

		
	}
	
	
}
