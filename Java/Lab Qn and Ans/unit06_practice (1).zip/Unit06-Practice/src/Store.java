

import java.util.ArrayList;

public class Store {
	private String name;
	
	//TODO 17: Add an array to store glasses and food items (what should we do? see Todo 18-21 first)
	
	public Store(String name)
	{
		this.name = name;
		
	}
	
	/**
	 * TODO 18: create a new interface called Priced (means has a price)
	 * 
	 * //TODO 19: create an abstract method called getPrice() that returns (double)
	 */

	//TODO 22: create a method called addPricedItem() to add any item to the store
	
	//TODO 23: create a method called getTotalItemsPrice that returns the 
	//         sum of the price of all items in this store
	
	//TODO 27: create a method called printAllExpiries() that will print the 
	//         expiry dates of the items in this store
}
