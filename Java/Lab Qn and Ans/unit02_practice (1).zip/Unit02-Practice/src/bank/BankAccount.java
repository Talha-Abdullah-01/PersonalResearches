package bank;

public class BankAccount {
	//TODO 1: create two public instance variables "owner" (String) and "balance" (double) for the bank account


	//TODO 11: create a custom constructor to initialize owner and balance
	// Q: will there be errors inside your App.java? Why do we have an error and how to fix it?

	
	

	//TODO 2: create a method to deposit money into the account

	
	//TODO 3: create a method to withdraw money from the account

	
	//TODO 4: create a method to return a String describing the account

	
	
	//TODO 13: create a static method that will convert any amount from QAR to USD.

}
