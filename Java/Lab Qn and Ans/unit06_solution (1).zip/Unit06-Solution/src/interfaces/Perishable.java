package interfaces;

public interface Perishable {
	/**
	 * TODO 14: create an interface called Perishable (it means it expires)
	 * 
	 *  //TODO 15: add an abstract method called getExpiry() that returns "expired" label String
	 */
	
	public String getExpiry();
}
