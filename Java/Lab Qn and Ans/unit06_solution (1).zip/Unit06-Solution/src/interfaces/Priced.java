package interfaces;

public interface Priced {
	/**
	 * TODO 18: create a new interface called Priced (means has a price)
	 * 
	 * //TODO 19: create an abstract method called getPrice() that returns (double)
	 */
	
	public double getPrice();
}
