package courses;

public class Runner {

	public static void main(String[] args) {
		
		
		//TODO 04: create a course.
		//TODO 04a: can you create the course in one line?
		
		
		
		//TODO 05: display the course information and instructor information
		
	}

}
