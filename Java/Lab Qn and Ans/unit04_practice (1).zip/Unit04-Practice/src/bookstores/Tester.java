package bookstores;

public class Tester {

	public static void main(String[] args) {
		
		Book orgBook = new Book("Hunger Games");
		BookStore orgStore = new BookStore("Jarir", orgBook);
		
		
		
		//TODO 06: make a new book call it copyBook and make the title also "Hunger Games"
		
		//TODO 07: make a new Bookstore call it copyStore and make the name "Jarir", and assign it copyBook as the bestSeller
		
		//TODO 08: using an if statement, can you check if orgBook is the same as copyBook?
		
		//TODO 10: use your work from todo 9 to compare the two books again
		
		//TODO 11: using an if statement, can you check if orgStore is the same as copyStore?
		
		//TODO 13: use your work from todo 12 to compare the two book stores again
		
		
		//TODO 15: Print all books inside of orgStore

		
		
	}
	
	

}
