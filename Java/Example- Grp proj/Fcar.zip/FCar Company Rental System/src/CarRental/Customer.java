package CarRental;

/**
 * @author Abdelrahman, Talha
 * @version 1.0
 * @since 21/10
 * Class Customer which has the Detailed information about the Customers
 */
public abstract class Customer {
	
	/**
	 * Initializing all the needed variables for the Class
	 */
	private int customerid;
	private String name;
	private String phone;
	private String address;
	private String nationality;
	private String drivingLicence;
	
	/**
	 * @param customerid
	 * The Specified id of the Customer
	 * @param name
	 * The Name of the Customer
	 * @param phone
	 * The Phone Number of the Customer
	 * @param address
	 * The Address of the Customer
	 * @param nationality
	 * The Nationality of the Customer
	 * @param drivingLicence
	 * Customers driving license
	 */
	
	/**
	 * Constructor that initializes all the variables inside the class
	 *
	 */
	public Customer(int customerid,String name,String phone,String address,String nationality,String drivingLicence) {
		super();
		this.customerid=customerid;
		this.name=name;
		this.phone=phone;
		this.address=address;
		this.nationality=nationality;
		this.drivingLicence=drivingLicence;
	}
	
	/**
	 *Implementing all the getters for the given variables inside the class
	 */
	
	
	/**
	 * @return The Customer ID
	 */
	public int getCustomerid() {
		return customerid;
	}
	
	
	/**
	 * @return The Name of the Customer
	 */
	public String getName() {
		return name;
	}
	
	
	/**
	 * @return The Phone Number of the Customer
	 */
	public String getPhone() {
		return phone;
	}
	
	
	/**
	 * @return The Address of the Customer
	 */
	public String getAddress() {
		return address;
	}
	
	
	/**
	 * @return The Nationality of the Customer
	 */
	public String getNationality() {
		return nationality;
	}
	
	
	/**
	 * @return The Driving License
	 */
	public String getDrivingLicence() {
		return drivingLicence;
	}
	
	
	/**
	 * The toString Method which is to Override
	 */
	@Override
	public String toString() {
		return "Customer ID : " + customerid+ "\n Name is : "+ name+ "\n Phone number is : "+phone+"\n Address is : "+address+ "\n Nationality is : "+nationality+"\n drivingLicence : "+drivingLicence; 
	}
}
