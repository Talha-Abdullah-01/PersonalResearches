package CarRental;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * @author Abdelrahman, Talha, Mohamad , Hassan
 * @version 1.0
 * @since 23/10
 * Class Invoice which has Details of the payment
 */
public class Invoice {
	
private int invoiceNo;
private LocalDate invoiceDate;
private List<Payment>payments;

/**
 * @param invoiceNo
 * The Invoice Number of the Payment
 * @param invoiceDate
 * The Invoice Date of the Payment
 * @param payments
 * The Arraylist which stores all the payments
 */

/**
 * Constructor that initializes all the variables inside the class
 *
 */
public Invoice(int invoiceNo, LocalDate invoiceDate, List<Payment> payments) {
	super();
	this.invoiceNo = invoiceNo;
	this.invoiceDate = invoiceDate;
	this.payments = payments;
}

/**
 *Implementing all the getters and setters for the given variables inside the class  
 */

/**
 * @return The invoice number of the payment
 */
public int getInvoiceNo() {
	return invoiceNo;
}

/**
 * @param invoiceNo sets the invoice Number of the payment to a new invoice Number
 */
public void setInvoiceNo(int invoiceNo) {
	this.invoiceNo = invoiceNo;
}

/**
 * @return the Invoice Date of the payment
 */
public LocalDate getInvoiceDate() {
	return invoiceDate;
}

/**
 * @param invoiceDate sets the invoice Date to a new Date
 */
public void setInvoiceDate(LocalDate invoiceDate) {
	this.invoiceDate = invoiceDate;
}

/**
 * @return the payments list
 */
public List<Payment> getPayments() {
	return payments;
}

/**
 * @param payments sets the payment List
 */
public void setPayments(List<Payment> payments) {
	this.payments = payments;
}




/**
 * @param Payment Takes A new Payment and modifies it with an existing payment
 */
public void modifyPayment(Payment Payment){
	{
		for(Payment temp:payments)
			if(temp == Payment)
			{
				System.out.println("Please Select A Desired Option:\n");
				System.out.println("1) Changing Payment Desc");
				System.out.println("2) Changing Payment ID");
				System.out.println("3) To change the price");
				
				Scanner input=new Scanner(System.in);
				
				int choice=input.nextInt();
				switch(choice)
				{
				
				
				case 1:
					System.out.print("Please input a new description:");
					temp.setPaymentDescription(input.next());
					break;	
				
				case 2:
					System.out.print("Please input a new payment ID:");
					temp.setPaymentId(input.nextInt());;
					break;	
					
				case 3:
					System.out.print("Please input a new Price:");
					temp.setPrice(input.nextDouble());
					break;
				
				default: System.err.println("Invalid Choice!");	
				}
				
			}
		
	}

}
	// delete method 
	
	/**
	 * @param paymentId The delete payment takes the ID 
	 * @return after deleting the information of the Payment
	 */
	public String deletePayment(int paymentId)
	{
		for(int i=0 ; i<payments.size() ; i++)
		{
			if(payments.get(i).getPaymentId()==paymentId) {
				payments.remove(i);
				return "Payment Successfully Deleted\n";
			}
		}
		return "Payment Not Found\n";
	}
	
	// add method
	
	
	/**
	 * @param payment Takes a Payment value and adds it to the payment List
	 */
	public void addPayment(Payment payment)
	{
		payments.add(payment);
	}
	
	
	/**
	 * @param paymentId Takes the Payment ID
	 * @return the payment which has the ID as the given Payment ID
	 */
	public Payment getPayment(int paymentId)
	{
		for(Payment temp : payments)
			if(temp.getPaymentId() == paymentId)
				return temp;
		
		return null;
		
	}
	
	// calculate Total method 
	
	/**
	 * @return the total of the Payment from the payment List
	 */
	public double calculateTotalPayment()
	{
		double total=0;
		
		for(Payment temp:payments)
			total+=temp.getPrice();
		return total;
	}


		

}


