package CarRental;



public enum CarType {
	
	/**
	 * @author Hassan
	 * @version 1.0
	 * @since 21/10
	 *Class Named CarType which has the list of Different Cars
	 */ 
	
	
		SEDAN,SUV,VAN,TRUCK;	
	}

	

