package CarRental;
import java.time.LocalDate;
import java.util.Date;

public class Payment {
	
	/**
	 * @author Mohamad 
	 * @version 1.0
	 * @since 21/10
	 * This is the Class Payment
	 * 
	 */
	
	/**
	 * Initializing all the needed variables for the Class
	 */ 
	private String paymentDescription;
	private int paymentId;
	private double price;
	private LocalDate paymentDate;
	/**
	 * 
	 * @param paymentDescription 
	 * The Description of the Payment
	 * @param paymentId
	 * The ID specified to the payment
	 * @param price
	 * The Price of the payment
	 * @param paymentDate
	 * The Date when the payment is made
	 */
	
	/**
	 * Constructor that initializes all the variables inside the class
	 *
	 */
	public Payment(String paymentDescription, int paymentId,double price,LocalDate paymentDate) {
		this.paymentDescription=paymentDescription;
		this.paymentId=paymentId;
		this.price=price;
		this.paymentDate=paymentDate;
	}

	/**
	 *Implementing all the getters and setters for the given variables inside the class  
	 */
	
	/**
	 * @return the payment Description
	 */
	public String getPaymentDescription() {
		return paymentDescription;
	}

	
	/**
	 * @param paymentDescription Sets the Payment Description
	 */
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}

	
	/**
	 * @return The Payment ID
	 */
	public int getPaymentId() {
		return paymentId;
	}

	
	/**
	 * @param paymentId Sets the Payment ID
	 */
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	

	/**
	 * @return the Price of the Payment
	 */
	public double getPrice() {
		return price;
	}
	

	/**
	 * @param price Sets a new price of the Payment
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	

	/**
	 * @return The Payment Date
	 */
	public	LocalDate getPaymentDate() {
		return paymentDate;
	}

	
	/**
	 * @param newDate Sets a new Date for the Payment
	 */
	public void setPaymentDate(LocalDate newDate) {
		this.paymentDate = newDate;
	}

	/**
	 * The toString Method which is to OverRide
	 */
	@Override
	public String toString() {
		return "Payment Description : " + paymentDescription + "\n payment Id : "+paymentId+"\n price : "+price+"\n Payment Date : "+paymentDate;
	}
}
