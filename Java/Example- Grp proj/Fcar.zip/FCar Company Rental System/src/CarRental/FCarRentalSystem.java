package CarRental;

import java.util.ArrayList;
import java.time.LocalDate;

/**
 * @author  Abdelrahman, Talha, Mohamad , Hassan
 * @version 1.0
 * @since 24/10
 * The Class FCarRentalSystem designed to create different Methods
 */
public class FCarRentalSystem {
		
		/**
		 * Creating Arraylist which is from the classes Customer,Car and Rental
		 */
		private ArrayList<Customer> customers = new ArrayList<Customer>();
		private ArrayList<Car> Cars = new ArrayList<Car>();
		private ArrayList<Rental> rentals = new ArrayList<Rental>();
		
		
		/** 
		 *Creating a Constructor with all the Attributes
		 */
		
		public FCarRentalSystem(ArrayList<Customer> customers, ArrayList<Car> cars, ArrayList<Rental> rentals) {
			super();
			this.customers = customers;
			this.Cars = cars;
			this.rentals = rentals;
		}

		/**
		 *Implementing all the getters for the given Arraylists inside the class  
		 */
		
		
		/**
		 * @return The ArrayList of the Customer
		 */
		public ArrayList<Customer> getCustomers() {
			return customers;
		}
		
		/**
		 * @return The Arraylist of Car
		 */
		public ArrayList<Car> getCars() {
			return Cars;
		}
		
		
		/**
		 * @return The ArrayList of Rental
		 */
		public ArrayList<Rental> getRentals() {
			return rentals;
		}
		
		/**
		 * @param tcar Takes the entered car and adds it to the Car ArrayList
		 */
		public void addCar(Car tcar)
		{
			Cars.add(tcar);
		}
		
		
		/**
		 * @param plateNO Takes the PlateNumber
		 * @return displays all the information of a Car which has the same PlateNumber as Entered
		
		 */
		public Car findCar(String plateNO)
		{
			for(Car temp : Cars)
			{
				if(temp.getPlateNo() == plateNO)
					return temp;
			}
			return null;
		}
		
		
		/**
		 * @param plateNO Takes the Plate Number of a car and deletes it information from the Car Arraylist
		 */
		public void deleteCar (String plateNO)
		{
			for(int i=0;i<Cars.size();i++)
			{
				if(Cars.get(i).getPlateNo()==plateNO)
					Cars.remove(i);
			}	
			
		}
		
		
		/**
		 * @param customer To add customer inside the Customer ArrayList
		 */
		public String addCustomer(Customer customer)
		{
			 customers.add(customer);
			 return "Added Customer\n";
		}
		
		
		/**
		 * @param customerId takes the customer id
		 * @return the information of the customer id with the same customer id as entered
		 */
		public Customer findCustomer( int customerId)
		{
			for(Customer temp:customers)
			{
				if(temp.getCustomerid()==customerId)
					return temp;
			}
			return null;
			
		}
		
		
		/**
		 * @param customerId Takes a Customer ID and deletes the Customer information which has the same ID

		 */
		public void deleteCustomer(int customerId) 
		{
			for(int i=0;i<customers.size();i++)
			{
				if(customers.get(i).getCustomerid()==customerId)
					customers.remove(i);
			}	
			
		}
		
		/**
		 * @param plateNo This Method takes Plate Number . It Searches through invoice, it will get the invoice through rental arraylist
		 * @return returns a Car
		 */
		public Invoice returnCar(String plateNo) {
			Invoice k = null;
			for (var l : getRentals()) {
				if (l.getCar().getPlateNo().equals(plateNo)) {
					k = l.getInvoice();
					break;
				}
			}
			for (var j : getCars()) {
				if (j.getPlateNo().equals(plateNo)) {
					j.setAvailable(true);
					break;
				}
			}
			return k;
		}
		
	
		/**
		 * @param available Takes the availability to check for car availability
		 * @return returns the Availability of car if its taken or not, if its not taken, adds it to the Car Arraylist as a new information
		 */
		public ArrayList<Car> getCarByavailability(boolean available)
		{
			ArrayList<Car>housesToSend=new ArrayList<Car>();
			for(Car temp:Cars)
			{
				if(temp.isAvailable()==available)
				{
					housesToSend.add(temp);
				}
			}
			return housesToSend;
		}
		
		
		/**
		 * @param method takes rental, checks if the Customer is Resident
		 * If its a Resident it adds the rental in the Rental Arraylist and sets availability to false / or taken
		 * If it is a Visitor, it checks if the visitors Visa Expiry ends before end date, it will not accept
		 * Otherwise it will add the visitor to the Rental Array
		 * @return
		 */
		public void bookCarRental(Rental rental)
		{
			for (Car i : getCars()) 
			{
			if (rental.getCustomer() instanceof Resident) { 
				if (rental.getCar().getPlateNo().equals(i.getPlateNo())) {
					Rental.add(rental);
					i.setAvailable(false);
				} 
			} 
			else if (rental.getCustomer() instanceof Visitor) 
				{
				Visitor visitor = (Visitor) rental.getCustomer(); //cast to Visitor
				if (visitor.getVisaExpiryDate().isBefore(rental.getEndDate())) { // check if visa expires before end of Date of Rent
					System.out.println("You cant rent a car before the Visa Expires");
					return ;
				} 
				else if (rental.getCar().getPlateNo() == i.getPlateNo()) 
					{
					Rental.add(rental);
					i.setAvailable(false);
					} 
				
				} 
			} 
		
		}
		
		
		/**
		 * @param customerId this method takes Customer id
		 * Makes a new Arraylist rent ; Adds all the Information which have the same id 
		 * @returns the New Arraylist created
		 */
		public ArrayList<Rental> findCarRentalByCustomerId(int customerId) {
			ArrayList<Rental> rent = new ArrayList<>();
			for (Rental i : getRentals()) {
				if (i.getCustomer().getCustomerid() == customerId) {
					rent.add(i);
				}
			}
			return rent;
		}
		
		
		/**
		 * @param customerId, this method takes customer id
		 * Compares which given id corresponds to the entered customer id, Changes its availability to True/not taken
		 * Deletes that specific Information
		 */
		public void deleteCarRental(int customerId) {
			for (Rental i : getRentals()) {
				if (i.getCustomer().getCustomerid() == customerId) {
					i.getCar().setAvailable(true);
					getRentals().remove(i);
					break;
				}

			}

		}
		
		/**
		 * @param date, this method Takes Date, then Creates a new Arraylist called cars
		 * It then Checks from Car Arraylist which car are available, and adds it to the Car
		 * It then checks the rental Arraylist, checks if End date is before The given Date, then adds the car to the new arraylist
		 * @return the new arraylist 
		 */
		public ArrayList<Car> getAvailableCarsByDate(LocalDate date) {
			ArrayList<Car> cars = new ArrayList<>();
			for (Car i : getCars()) {
				if (i.isAvailable() == true) {
					cars.add(i);
				}
			}
			for (Rental i : getRentals()) {
				if (i.getEndDate().isBefore(date)) {
					cars.add(i.getCar());
				}
			}
			return cars;
		}
		
}


