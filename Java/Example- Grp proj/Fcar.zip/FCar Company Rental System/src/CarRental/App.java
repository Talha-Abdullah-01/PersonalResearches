package CarRental;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Talha
 * @version 1.0
 * @since 25/10
 * Testing class that will test all methods, made as a menu
 */
public class App {
	public static void main(String[] args) {
		Scanner cin = new Scanner(System.in);

		
		int Rental = 20;
		int VisitorId = 30;
		int ResidentId = 40;
		int PaymentId = 50;
		int InvoiceNo = 60;
		int customerId=20;
		double price;
		String desc;

		// Creating Arraylist for the FcarRental System
		ArrayList<Car> cars = new ArrayList<>();
		ArrayList<Customer> customers = new ArrayList<>();
		ArrayList<Rental> rentals = new ArrayList<>();
		FCarRentalSystem F = new FCarRentalSystem(customers, cars, rentals);
		ArrayList<Payment> payments = new ArrayList<>();

		// adding car informations to the System
		F.addCar(new Car("1", "GMC", CarType.SEDAN, true));
		F.addCar(new Car("2", "LandCruiser", CarType.SEDAN, true));
		F.addCar(new Car("3", "BMW", CarType.SUV, true));
		F.addCar(new Car("4", "Camry", CarType.TRUCK, true));

	//creating a do while Loop for a menu Bar
		boolean exit = true;
		do {
			System.out.println("Welcome to the Rental System! ");
			System.out.printf("Please choose from the Options Below:"
					+ "\n1- Add customer"
					+ "\n2- Find customer by ID"
					+ "\n3- Delete customer"
					+ "\n4- Add car"
					+ "\n5- Find car"
					+ "\n6- Delete car"
					+ "\n7- Get car if it is available"
					+ "\n8- Return a specific car"
					+ "\n9- Book a car "
					+ "\n10- Find a car rental by Its ID."
					+ "\n11- Delete car rental."
					+ "\n12- Get avaialble cars through date."
					+ "\n13- Modify a payment through ID"
					+ "\n14- Delete a payment."
					+ "\n15- Add a payment"
					+ "\n16- Calculate total payment"
					+ "\n17- Exit\n");
			int num = cin.nextInt();
			cin.nextLine();

			switch (num) {
			case 1:
				//Adding Customer: Viewing if he is a resident or visitor
				System.out.printf("Resident or Visitor?\n ");
				String vr = cin.nextLine();
				System.out.printf("Please enter your name: ");
				String name = cin.nextLine();
				System.out.printf("Please Enter phone number: ");
				String phoneno = cin.nextLine();
				System.out.printf("Please Enter address: ");
				String addr = cin.nextLine();
				System.out.printf("Please Enter your nationallity: ");
				String nationality = cin.nextLine();
				System.out.printf("Enter your driving licence type: ");
				String license = cin.nextLine();
				// if He is a visitor, we proceed with asking questions regarding the visitor
				if (vr.equals("visitor")) {
					System.out.printf("Enter your passport Credential/ Passport Number : ");
					int passportno = cin.nextInt();
					System.out.printf("Provide your Entry Date : Enter The Year ");
					int y = cin.nextInt();
					System.out.printf("the month: ");
					int m = cin.nextInt();
					System.out.printf("the day: ");
					int d = cin.nextInt();
					LocalDate entryDate = LocalDate.of(y, m, d);
					System.out.printf("Provide your visa Expiry Date, Enter the year: ");
					int y2 = cin.nextInt();
					System.out.printf("the month: ");
					int m2 = cin.nextInt();
					System.out.println("the day: ");
					int d2 = cin.nextInt();
					cin.nextLine();
					LocalDate expiryDate = LocalDate.of(y2, m2, d2);

					// Now we call the method from the fCarRentalSystem object and display the Message
					
					F.addCustomer(new Visitor(VisitorId, name, phoneno, addr, nationality,license, passportno, entryDate, expiryDate));
					continue;
					// if he is a resident we will ask him for his id
				} else if (vr.equals("Resident")) {
					System.out.printf("Enter your Qatar ID: ");
					int id = cin.nextInt();
					cin.nextLine();
					System.out.println(
							F.addCustomer(new Resident(VisitorId, name, phoneno, addr, nationality, license, id))+ "Customer's ID: " + ResidentId);
					continue;
				}

				break;
			case 2:
				// Finding Customer through his Id
				System.out.println("Enter customer id: ");
				int id = cin.nextInt();
				Customer customer = F.findCustomer(id);
				if (customer != null)
					System.out.println("Customer is there and his name : " + F.findCustomer(id).getName());
				else
					System.out.println("Customer is not there, please add a customer");

				break;
			case 3:
				// Deleting a Customer through his ID
				System.out.printf("Enter Customer ID to delete it: ");
				int id3 = cin.nextInt();
				cin.nextLine();
				F.deleteCustomer(id3);
				break;
			case 4:
				// Adding a New Car
				System.out.printf("Enter Car PlateNo ");
				String plateNo = cin.nextLine();
				System.out.printf("Enter Its Model: ");
				String model = cin.nextLine();
				System.out.printf("Enter the type of Car: ");
				String carType = cin.nextLine();

				// Setting the CarType
				CarType style = null;
				if (carType.equals("sedan"))
					style = CarType.valueOf("SEDAN");
				else if (carType.equals("suv"))
					style = CarType.valueOf("SUV");
				else if (carType.equals("van"))
					style = CarType.valueOf("VAN");
				else if (carType.equals("truck"))
					style = CarType.valueOf("TRUCK");
				// Adding the Car
				F.addCar(new Car(plateNo, model, style, true));
				break;
			case 5:
				// To Find Car through its Plate Number
				System.out.println("Enter The Plate number of the Car ");
				String plateNo3 = cin.nextLine();
				// Making Car Object and returning value
				Car car = F.findCar(plateNo3);
				if (car != null)
					System.out.println("Car has been found, Its model is: " + car.getModel() + ", the type of the car is: "
							+ car.getType() + ",Its  availability : " + car.isAvailable());
				else
					System.out.println("Car is not Registered!");
				break;
			case 6:
				// Testing the Delete Car Method
				System.out.print("Enter any Plate Number to Delete ");
				String plateNo4 = cin.nextLine();
				// call the method Here
				F.deleteCar(plateNo4);
				break;
			case 7:
				// Testing Get Available Car
				System.out.printf("Do you want Car to be Available or not? Press True or False to use this ");
				boolean Taken = cin.nextBoolean();

				// Create Arraylist and then return the available Cars
				ArrayList<Car> carsByAvailabilty;
				carsByAvailabilty = F.getCarByavailability(Taken);
				if (carsByAvailabilty.size() != 0) {
					for (var i : carsByAvailabilty) {
						System.out.printf("Model: %s\tType: %s\tPlate number %s\n", i.getModel(), i.getType(),i.getPlateNo());
					}
				} else
					System.out.println("No Cars Are there as such");
				break;
			case 8:
				// To Return a Car
				System.out.println("Enter PlatNo of the Car you want :  ");
				String plateNo5 = cin.nextLine();

				// We make Invoice object and then return invoice information
				Invoice invoice = F.returnCar(plateNo5);
				System.out.println("Car returned!, the invoice number is: " + invoice.getInvoiceNo()
						+ ", and the total payment is: " + invoice.calculateTotalPayment());
				break;
			case 9:

				// To Check BookCar Rental
				System.out.printf("Are you A Customer" + "\nReply with yes or no: ");
				String yn = cin.nextLine();
				if (yn.equals("no")) {
					System.out.println("You can only register as a customer");
					continue;
				}
				// Since it is a customer, we need more Details
				System.out.printf("Please enter your customer ID so you could rent a car: ");
				customerId = cin.nextInt();
				Customer customer2 = F.findCustomer(customerId);
				cin.nextLine();
				System.out.printf("From list of Cars, choose one which is available : ");
				String plateNo6 = cin.nextLine();
				Car c2 = F.findCar(plateNo6);
				System.out.println("Enter The Start and Date of your Rental : ");
				System.out.printf("Enter The Start Date , The Year:  ");
				int y2 = cin.nextInt();
				System.out.printf("Enter the month: ");
				int m2 = cin.nextInt();
				System.out.printf("Enter the day: ");
				int d2 = cin.nextInt();
				LocalDate startDate = LocalDate.of(y2, m2, d2);
				System.out.printf("Enter the Amount of Days you need to Rent the Car :");
				int days = cin.nextInt();
				// End Date depends on the number of Days the Car is Rented
				LocalDate endDate = startDate.plusDays(days);
				System.out.println("Enter the Amount ");
				double Amount = cin.nextDouble();
				cin.nextLine();
				price = days * 100;
				System.out.println("The end date is: " + endDate);

				// Pass this information to the Invoice object
				payments.add(new Payment("Payment based on the Days it is rented", PaymentId, price, endDate));
				// we create a invoice object so we can pass it to the rental object
				Invoice i2 = new Invoice(InvoiceNo, endDate, payments);
				// Now using the invoice we add this through our method
				F.bookCarRental(new Rental(Rental, customer2, c2, startDate, endDate, i2));
				System.out.printf("Car is now rented! Rental id is: %d, Inovice id is: %d, Payment ID: %d\n", Rental,InvoiceNo, PaymentId);
				break;
			case 10:
				// here Testing the Car Rental by Customer ID
				System.out.printf("Enter Customers ID to search his rentals ");
				customerId = cin.nextInt();
				cin.nextLine();
				// Create an Arraylist and equal its ID
				ArrayList<Rental> rentalsById = F.findCarRentalByCustomerId(customerId);
				// we display some information
				if (rentalsById.size() != 0) {
					System.out.println("Rental not found.");
					for (var i : rentalsById) {
						System.out.printf("Rental number is : %d,\tCar plate is: %s\tInvoice number is: %d\n", i.getRentalNo(),
								i.getCar().getPlateNo(), i.getInvoice().getInvoiceNo());

					}
				} else {
					System.out.println("This Customer ID has no rentals");
				}
				break;
			case 11:
				// Checking the Delete Rental
				System.out.printf("Enter Customer ID to delete his rental info:");
				customerId = cin.nextInt();
				cin.nextLine();
				// Calling method to delete the rental through his ID
				F.deleteCarRental(customerId);
				break;
			case 12:
				// Test GetAvailable Car through Date
				System.out.printf("Enter the Date you want your Car to be Rented .Enter the year: ");
				int y3 = cin.nextInt();
				System.out.printf("Enter month: ");
				int m3 = cin.nextInt();
				System.out.printf("Enter day: ");
				int d3 = cin.nextInt();
				cin.nextLine();
				// Calling Method
				ArrayList<Car> carsTrue = F.getAvailableCarsByDate(LocalDate.of(y3, m3, d3));
				if (carsTrue.size() != 0) {
					System.out.println("Cars found.");
					for (var i : carsTrue) {
						System.out.printf("The Plate number is : %s,\t The Model is : %s,\tThe Type is : %s\n", i.getPlateNo(), i.getModel(),
								i.getType());
					}
				} else {
					System.out.println("No Available Cars");
				} 
				break;
			case 13:
				// To Test Modify Payment
				System.out.printf("Modify a Payment, ENter ID of Customer ");
				customerId = cin.nextInt();
				System.out.println("Enter payment ID ");
				PaymentId = cin.nextInt();
				System.out.printf("Enter invoice Number : ");
				InvoiceNo = cin.nextInt();
				cin.nextLine();
				System.out.printf("Enter a New description: ");
				desc = cin.nextLine();
				System.out.printf("Enter the new price: ");
				price = cin.nextInt();
				cin.nextLine();

				i2 = null;

				// Searching for the invoice
				for (var i : F.findCarRentalByCustomerId(customerId)) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i2 = i.getInvoice();
				}

				// 
				for (var i : i2.getPayments()) {
					if (i.getPaymentId() == PaymentId) {
						i2.modifyPayment(new Payment(desc, PaymentId, price, i2.getInvoiceDate()));
					}
				}

				// Saving Changes
				for (var i : F.getRentals()) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i.setInvoice(i2);

				}
				break;
			case 14:
				// Testing Delete Payment Method
				System.out.printf("Delete Payment through ID. ENter Customer ID");
				customerId = cin.nextInt();
				System.out.println("Enter Payment ID you want to delete ");
				PaymentId = cin.nextInt();
				System.out.printf("Enter the invoice number that payment ID is in: ");
				InvoiceNo = cin.nextInt();
				cin.nextLine();
				i2 = null;

				//Searching for invoice
				for (var i : F.findCarRentalByCustomerId(customerId)) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i2 = i.getInvoice();
				} //getting the payments for invoice
				for (var i : i2.getPayments()) {
					if (i.getPaymentId() == PaymentId) {
						System.out.println(i2.deletePayment(PaymentId));
						break;
					}
				}
				// Saving the rentals
				for (var i : F.getRentals()) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i.setInvoice(i2);
				}

				break;
			case 15:
				// Test Add Payment Method
				System.out.printf("Add a payment through customer ID ");
				customerId = cin.nextInt();
				System.out.printf("Enter invoice number ");
				InvoiceNo = cin.nextInt();
				cin.nextLine();
				System.out.printf("Enter payment Description: ");
				desc = cin.nextLine();
				System.out.printf("Enter price: ");
				price = cin.nextDouble();
				cin.nextLine();
				i2 = null;

				// To get new invoice to add payment
				for (var i : F.findCarRentalByCustomerId(customerId)) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i2 = i.getInvoice();
				} 
					// we call the method and to display it in string
				
						i2.addPayment(new Payment(desc, PaymentId, price, i2.getInvoiceDate()));
				// Saving Date
				for (var i : F.getRentals()) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i.setInvoice(i2);
				}
				break;
			case 16:
				// Calculating total
				System.out.printf("Enter your CUstomer ID ");
				customerId = cin.nextInt();
				System.out.printf("Enter your invoice Number ");
				InvoiceNo = cin.nextInt();
				i2 = null;
				// finding invoice from rentals
				for (var i : F.findCarRentalByCustomerId(customerId)) {
					if (i.getInvoice().getInvoiceNo() == InvoiceNo)
						i2 = i.getInvoice();
				} //calculating total
				System.out.println("Total payments: " + i2.calculateTotalPayment());
				break;
			case 17:
				//setting boolean to false
				System.out.println("Thank you for coming!");
				exit = false;
				break;
			}
		} while (exit);
	}
}
