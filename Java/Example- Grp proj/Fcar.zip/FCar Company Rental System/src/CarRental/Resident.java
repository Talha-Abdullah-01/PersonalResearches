package CarRental;

/**
 * @author Abdelrahman
 * @version 1.0
 * @since 22/10
 * Class Resident Which inherits from Customer
 */
public class Resident extends Customer{
	
	private int qatarId;
	
	/**
	 * @param customerid Inherited From Customer
	 * @param name Inherited From Customer
	 * @param phone Inherited From Customer
	 * @param address Inherited From Customer
	 * @param nationality Inherited From Customer
	 * @param drivingLicence Inherited From Customer 
	 * @param qatarId 
	 * The Qatar Id of the Customer
	 */
	
	/**
	 * Constructor that initializes all the variables inside the class
	 *
	 */
	public Resident(int customerid,String name,String phone,String address,String nationality,String drivingLicence, int qatarId) {
		super(customerid,name,phone,address,nationality,drivingLicence);
		this.qatarId=qatarId;
	}
	
	/**
	 *Implementing all the getters for the given variables inside the class  
	 */
	
	/**
	 * @return the Qatar ID of the Customer
	 */
	public int getQatarId() {
		return qatarId;
	}
	
	/**
	 * The toString Method which is to Override
	 */
	
	@Override
	public String toString() {
		return super.toString()+ "\n Qatar ID : "+qatarId; 
	}
}
