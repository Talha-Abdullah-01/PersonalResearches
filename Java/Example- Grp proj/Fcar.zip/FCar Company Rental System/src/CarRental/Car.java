package CarRental;

/**
 * @authorTalha, Mohamad 
 * @version 1.0
 * @since 20/10
 * The Class Named Car which has the detailed information about the Car
 */

public class Car {
	/**
	 * Instantiating variable names needed for the class
	 */
	private String plateNo;
	private String model;
	private CarType type;
	private boolean isAvailable;
	
	
	
	
	/**
	 * @param plateNo
	 * The Plate Number of the Car
	 * @param model
	 * The Model Number of the Car
	 * @param type
	 * The type of the Car
	 * @param isAvailable
	 * To check if the Car is Available or not
	 */
	
	/**
	 * Constructor that initializes all the variables inside the class
	 *
	 */
	public Car(String plateNo, String model, CarType type,boolean isAvailable) {
		super();
		this.plateNo=plateNo;
		this.model=model;
		this.type=type;
		this.isAvailable=isAvailable;
	}
	
	
	
	/**
	 * Getters for all the variables inside the class and setters for the needed
	 */
	
	
	/**
	 * @return The Plate Number of the Car
	 */
	public String getPlateNo() {
		return plateNo;
	}
	




	/**
	 * @return The Mode of The Car
	 */
	public String getModel() {
		return model;
	}
	
	
	/**
	 * @return The type of the Car
	 */
	public CarType getType() {
		return type;
	}
	
	
	/**
	 * @return If the Car is Available or Not
	 */
	public boolean isAvailable() {
		return isAvailable;
	}
	
	/**
	 * @param To set the availability of car
	 */
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	
	
	/**
	 * The toString Method which is to OverRide
	 */
	@Override
	public String toString() {
		return "Car " + "\n plat Number : "+plateNo+"\n Model  : "+model+"\n Type  : "+type+"\n Available : "+isAvailable;
	}
}