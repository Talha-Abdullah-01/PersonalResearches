package CarRental;

import java.time.LocalDate;
import java.util.Date;

/**
 * @author Hassan
 * @version 1.0
 * @since 22/10
 *The Class Rental with the detailed information like the start date, end date etc
 */


/**
 * @author Talha
 *
 */
public class Rental {
private int rentalNo;
private Customer customer;
private Car car;
private LocalDate StartDate;
private LocalDate EndDate;
private Invoice invoice;

/**
 * @param rentalNo
 * The Rental Number
 * @param car
 * The Car which is Rented
 * @param StartDate
 * The Day it is rented
 * @param EndDate
 * The End Date of the rented car
 * @param invoice
 * The Invoice of the Rented Car
 */

/**
 * Constructor that initializes all the variables inside the class
 * @param amount 
 *
 */
public Rental (int rentalNo, Customer customer,Car car, LocalDate StartDate, LocalDate EndDate, Invoice invoice) {
	this.rentalNo=rentalNo;
	this.customer=customer;
	this.car=car;
	this.StartDate=StartDate;
	this.EndDate=EndDate;
	this.invoice=invoice;
}

/**
 *Implementing all the getters and setters for the given variables inside the class  
 */


/**
 * @return The Rental Number
 */
public int getRentalNo() {
	return rentalNo;
}

/**
 * @return The Customer info from class Customer
 */
public Customer getCustomer() {
	return customer;
}

/**
 * @param To set Customer info from class Customer
 */
public void setCustomer(Customer customer) {
	this.customer = customer;
}

/**
 * @param rentalNo set the Rental Number to a new value
 */
public void setRentalNo(int rentalNo) {
	this.rentalNo = rentalNo;
}


/**
 * @return The Car which is rented
 */
public Car getCar() {
	return car;
}


/**
 * @param car set the Car to a new Car
 */
public void setCar(Car car) {
	this.car = car;
}


/**
 * @return The Starting date of the Rented Car
 */
public LocalDate getStartDate() {
	return StartDate;
}


/**
 * @param startDate set the Starting Date to a new Date
 */
public void setStartDate(LocalDate startDate) {
	StartDate = startDate;
}


/**
 * @return The End Date of the Rented Car
 */
public LocalDate getEndDate() {
	return EndDate;
}


/**
 * @param endDate set the End Date to a new End Date
 */
public void setEndDate(LocalDate endDate) {
	EndDate = endDate;
}


/**
 * @return The Invoice from Class Invoice
 */
public Invoice getInvoice() {
	return invoice;
}


/**
 * @param invoice Set the Invoice to a new Invoice
 */
public void setInvoice(Invoice invoice) {
	this.invoice = invoice;
}

/**
 * The toString Method which is to Override
 */
@Override
public String toString() {
	return "Rental No : " + rentalNo+ "\n Car is : "+ car+ "\n Start Date is : "+StartDate+"\n End Date is : "+EndDate+ "\n Invoice : "+invoice; 
}

public static void add(Rental rental) {
	Rental.add(rental);// TODO Auto-generated method stub
}
}
