package CarRental;
import java.time.LocalDate;



/**
 * @author Talha
 * @version 1.0
 * @since 22/10
 *Class Visitor which inherited from Class Customer
 */
public class Visitor extends Customer {
	
	private int passportNo;
	private LocalDate entryDate;
	private LocalDate visaExpiryDate;
	
	/**
	 * @param customerid inherited From Customer
	 * @param name inherited From Customer
	 * @param phone inherited From Customer
	 * @param address inherited From Customer
	 * @param nationality inherited From Customer
	 * @param drivingLicence inherited From Customer
	 * @param passportNo 
	 * The Passport Number of the Customer
	 * @param entryDate
	 * The Entry Date of the Customer
	 * @param visaExpiryDate
	 * The Visa expiry Date of the Customer
	 */
	
	/**
	 * Constructor that initializes all the variables inside the class
	 *
	 */
	public Visitor(int customerid,String name,String phone,String address,String nationality,String drivingLicence,int passportNo,LocalDate entryDate,LocalDate expiryDate) {
		super(customerid,name,phone,address,nationality,drivingLicence);
		this.passportNo=passportNo;
		this.entryDate=entryDate;
		this.visaExpiryDate=expiryDate;
	}
	
	/**
	 *Implementing all the getters for the given variables inside the class  
	 */
	
	
	/**
	 * @return The Passport Number of the Customer/visitor
	 */
	public int getPassportNo() {
		return passportNo;
	}
	
	/**
	 * @return The Entry Date of the Customer/visitor
	 */
	public LocalDate getEntryDate() {
		return entryDate;
	}
	
	/**
	 * @return The Visa Expiry Date of the customer/visitor
	 */
	public LocalDate getVisaExpiryDate() {
		return visaExpiryDate;
	}
	
	/**
	 * The toString Method which is to Override
	 */
	
	@Override
	public String toString() {
		return super.toString()+ "\n Passport Number : "+passportNo+"\n Entry Date is : "+entryDate+"\n Visa Expiry Date is : "+visaExpiryDate;
	}

}
