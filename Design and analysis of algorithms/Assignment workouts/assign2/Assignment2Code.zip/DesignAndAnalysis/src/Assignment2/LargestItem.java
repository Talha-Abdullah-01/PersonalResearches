package Assignment2;

import java.util.ArrayList;
import java.util.Scanner;

public class LargestItem {
public static void main(String [] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of the list : ");
	int n=sc.nextInt();
	System.out.println("Enter the list values : ");
	ArrayList<Integer> list=new ArrayList<>();
	for(int i=0;i<n;i++) {
		System.out.print(i+"th element : ");
		int z=sc.nextInt();
		System.out.println("");
		list.add(z);
	}
	int [] arr=new int[n];
	for(int i=0;i<n;i++) {
		arr[i]=list.get(i);
	}
	printArray(arr);
	LargestItem item=new LargestItem();
	item.sort(arr,0,arr.length-1);
	printArray(arr);
}
	public static void mergeArray(int arr[], int a, int k,int b)
    {
	int n=k-a+1;
	int m=b-k;
	int[] temp1=new int[n];
	int[] temp2=new int[m];
	for(int i=0;i<n;i++) {
		temp1[i]=arr[a+i];
	}
	for(int g=0;g<m;g++) {
		temp2[g]=arr[k+1+g];
	}
	
	int i=0; 
	int j=0;
	int z=1;
	while(i<n && j<m) {
		if(temp1[i]<=temp2[j]) {
			arr[z]=temp1[i];
			i++;
		}else {
			arr[z]=temp2[j];
			j++;
		}
		z++;
	}
	while(i<n) {
		arr[z]=temp1[i];
		i++;
		z++;
	}
	while(j<m) {
		arr[z]=temp2[j];
		j++;
		z++;
	}
	
}	
public static void sort(int arr[],int a,int b) {
	{
		
        if (a < b) {
            int k=a+(b-a)/2;
            sort(arr,a,k);
            sort(arr,k+1,b);
            mergeArray(arr,a , k ,b);
        }
    }
}
public static void printArray(int arr[])
    {
        int n = arr.length;
        for (int i = 0; i < n; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }
  
}
