package Assignment2;

import java.util.Scanner;

public class searchArray {
public static void main(String [] args) {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the Number of items in the array :");
	int n=sc.nextInt();
	int[] arr=new int[n];
	System.out.println("Enter the Sorted Array : \n");
	for(int i=0; i<n;i++) {
		System.out.print(i+"th index : ");
		int j=sc.nextInt();
		arr[i]=j;
	}
	System.out.println("Enter the term to find : ");
	int a=sc.nextInt();
	int z=arraysizeCheck(arr,a);
	System.out.println("Returned :"+z);
}
public static int arraysizeCheck(int [] arr,int a) {
	int k=0;
	int result=0;
	if(arr.length%3==1) {
		k=1;
//		for(int i=0;i<=arr.length;i++) {
		Object[] arrayObjects=dividearray(arr,k);
		int[] subarray1=(int[]) arrayObjects[0];
		int[] subarray2=(int[]) arrayObjects[1];
		int[] subarray3=(int[]) arrayObjects[2];
		if(a<subarray1[0] || a>subarray3[(arr.length-k)/3]) {
			System.out.println("Element not Found");
			result=0;
		}	
		else {
			if(a<=subarray1[((arr.length-k)/3)-k])
			{
			result=checkIfElementPresent(subarray1,a)-1;
			}
			else if(a>subarray1[((arr.length-k)/3)-k]) {
			result=checkIfElementPresent(subarray2,a)+((arr.length/3));
			}
			else {
			result=checkIfElementPresent(subarray3,a)+(2*(arr.length/3)+1);
			}
		}
	}
	else if(arr.length%3==2) {
		k=2;
		//for(int i=0;i<=arr.length;i++) {
		Object[] arrayObjects=dividearray(arr,k);
		int[] subarray1=(int[]) arrayObjects[0];
		int[] subarray2=(int[]) arrayObjects[1];
		int[] subarray3=(int[]) arrayObjects[2];
		if(a<subarray1[0] || a>subarray3[(arr.length-k)/3]) {
			System.out.println("Element not Found");
			result=0;
		}	
		else {
			if(a<=subarray1[((arr.length-k)/3)-k])
			{
			result=checkIfElementPresent(subarray1,a)-1;
			}
			else if(a>subarray1[((arr.length-k)/3)-k]) {
			result=checkIfElementPresent(subarray2,a)+((arr.length/3));
			}
			else {
			result=checkIfElementPresent(subarray3,a)+(2*(arr.length/3)+1);
			}
		}
	}
	
	else if(arr.length%3==0) {
		k=0;
	//	for(int i=0;i<=arr.length;i++) {
		Object[] arrayObjects=dividearray(arr,k);
		int[] subarray1=(int[]) arrayObjects[0];
		int[] subarray2=(int[]) arrayObjects[1];
		int[] subarray3=(int[]) arrayObjects[2];
		if(a<subarray1[0] || a>subarray3[(arr.length/3)-1]) {
			System.out.println("Element not Found");
			result=0;
		}	
		else {
			if(a<=subarray1[((arr.length-k)/3)-1])
			{
			result=checkIfElementPresent(subarray1,a)-1;
			}
			else if(a>subarray1[((arr.length-k)/3)-1]) {
			result=checkIfElementPresent(subarray2,a)+((arr.length/3));
			}
			else {
			result=checkIfElementPresent(subarray3,a)+(2*(arr.length/3)+1);
			}
		}
	}
	
return result;	
}
public static Object[] dividearray(int [] arr,int k){
	int n=arr.length;
	int z=0;
	if(k==1) {
		n=(arr.length-1)/3;
		z=n+1;
	}
	else if(k==2) {
		n=(arr.length-2)/3;
		z=n+2;
	}
	else {
		n=arr.length/3;
		z=n;
	}
	Object[] arrayObjects=new Object[3];
	int[] arr1=new int[n];
	for(int i=0;i<n;i++) {
		arr1[i]=arr[i];
	}
	int[] arr2=new int[n];
	int l=n;
	for(int i=0;i<n;i++) { 
		arr2[i]=arr[l];
		l++;
	}
	int[] arr3=new int[z];
	int j=2*n;
	for(int i=0;i<z;i++) {
		arr3[i]=arr[j];
		j++;
	}
	arrayObjects[0]=arr1;
	arrayObjects[1]=arr2;
	arrayObjects[2]=arr3;
	return arrayObjects;
}

public static int checkIfElementPresent(int [] arr,int a) {
	for(int i=0;i<arr.length;i++) {
	if(arr[i]==a) {
		return i;
	}
}
	return 0;
}
}