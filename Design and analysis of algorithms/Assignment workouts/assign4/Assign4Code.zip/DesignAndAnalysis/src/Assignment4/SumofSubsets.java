package Assignment4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class SumofSubsets {
public static void main(String [] args) {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter the Sum :" );
	int sum=sc.nextInt();
	System.out.print("Enter the Number of Elements in the array : ");
	int n=sc.nextInt();
	System.out.println("Enter the array elements : ");
	int[] providedArray = new int[n];
	for(int i=0;i<n;i++) {
		System.out.print(i+" = ");
		int x=sc.nextInt();
		providedArray[i]=x;
	}
	List<int[]> list=solver(sum,providedArray);
	if(list.isEmpty()) {
		System.out.println("No combinations give the provided sum");
		System.exit(0);
	}
	System.out.println("Printing List of Subsets that lead to the sum : ");
	list.forEach(array -> System.out.print(Arrays.toString(array)+"\t" ));
}
public static List<int[]> solver(int sum, int given[]){
	List<int[]> Answer = new ArrayList<int[]>();
	int k,z=0;
	int n=given.length;
	for(int i=0; i<n;i++) {
		for(int j=0;j<n;j++) {
			 if(given[i]+given[j]==sum) {
				 int [] array= {given[i],given[j]};
				 	Answer.add(array);
			 }
		}
	}
	return Answer;	
}
}
