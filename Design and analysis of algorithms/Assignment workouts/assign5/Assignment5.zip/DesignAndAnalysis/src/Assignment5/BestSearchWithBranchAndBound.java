package Assignment5;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

public class BestSearchWithBranchAndBound {
	
	
	public static void main(String [] args) {
	int w=16;
	Item arr[]= new Item[4];
	arr[0]=new Item(2,40);
	arr[1]=new Item(5,30);
	arr[2]=new Item(7,35);
	arr[3]=new Item(8,20);
	int n=arr.length;
	System.out.println("Maximum profit is = "+ks(w, arr, n));
	}
	public static int findBound(Node n, int z,int w,Item arr[]) {
		if(n.weight>=w) {
			return 0;
		}
		else {
			int profit=n.profit;
			int i=n.level+1;
			int totalweight=(int) n.weight;
			while(i<z && totalweight+arr[i].weight<=w) {
				totalweight+=arr[i].weight;
				profit+=arr[i].value;
				i++;
			}
			if(i<z) {
				profit+=(w-totalweight)*arr[i].value/arr[i].weight;
			}
			return profit;
		}
	}
	public static int ks(int w,Item arr[],int n) {
		for(int i=0;i<n-1;i++) {
			Item first=new Item(arr[i].weight,arr[i].value);
			Item second=new Item(arr[i+1].weight,arr[i+1].value);
			boolean c=compare(first, second);
			if(c==true) {
				arr[i]=arr[i+1];
			}
			else {
				arr[i]=arr[i];
			}
		}
		Queue<Node>q = new LinkedList<Node>();
		Node a = new Node(0, 0, 0, 0),b=new Node(0, 0, 0, 0);
		a.level=-1;
		a.profit=0;
		a.weight=0;
		q.add(a);
		int maxP=0;
		while(!q.isEmpty()) {
			a=q.peek();
			q.remove();
		if(a.level== -1) {
			b.level=0;
		}
		if(a.level==n-1) {
			continue;
		}
		b.level=a.level+1;
		b.weight=a.weight+arr[b.level].weight;
		b.profit=a.profit+arr[b.level].value;
		if(b.weight<=w && b.profit>maxP) {
			maxP=b.profit;
			b.bound=findBound(b,n,w,arr);	
		}
		if(b.bound>maxP) {
			q.add(b);
		}
		}
		return maxP;
	}
	public static boolean compare(Item first,Item second) {
		double r1=(double)first.value/first.weight;
		double r2=(double)second.value/second.weight;
		return r1>r2;
	}
}
