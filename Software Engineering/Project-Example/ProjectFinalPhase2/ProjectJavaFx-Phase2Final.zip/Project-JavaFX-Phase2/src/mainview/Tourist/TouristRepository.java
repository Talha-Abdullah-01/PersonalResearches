package mainview.Tourist;

import java.util.ArrayList;

import MainProject.IssueTouristVisa;
import MainProject.Tourist;



public class TouristRepository {
	public static ArrayList<Integer> getIds() {
		
		ArrayList<Integer> touristIds = new ArrayList<>();
		ArrayList<Tourist> t=IssueTouristVisa.ReadTest();
		if(t.size()!=0) {
		for (var tourist : t) {
			touristIds.add(tourist.getTouristId());
		}
		}
		return touristIds;
	}
	public static ArrayList<Integer> getPassportNumber() {
		ArrayList<Integer> touristPassport = new ArrayList<>();
		ArrayList<Tourist> t=IssueTouristVisa.ReadTest();
		if(t.size()!=0) {
		for (var tourist : t) {
			touristPassport.add(tourist.getTouristPassportNo());
		}
		}
		return touristPassport;
}
	public static void saveTourist(Tourist T) {
		ArrayList<Tourist> t = IssueTouristVisa.ReadTest();
		t.add(T);
		IssueTouristVisa.saveTourist(t);
	}
}
