package MainProject;

import java.io.Serializable;

public class Tourist implements Serializable{
	private static final long serialVersionUID = 6894463765965627542L;
	private int touristId,touristNumber,touristPassportNo,cardNumber;
	private String touristName,touristAddress,touristEmail;
	
	public Tourist(int touristId, int touristNumber, int touristPassportNo, int cardNumber, String touristName,
			String touristAddress, String touristEmail) {
		super();
		this.touristId = touristId;
		this.touristNumber = touristNumber;
		this.touristPassportNo = touristPassportNo;
		this.cardNumber = cardNumber;
		this.touristName = touristName;
		this.touristAddress = touristAddress;
		this.touristEmail = touristEmail;
	}
	public int getTouristId() {
		return touristId;
	}
	public void setTouristId(int touristId) {
		this.touristId = touristId;
	}
	public int getTouristNumber() {
		return touristNumber;
	}
	public void setTouristNumber(int touristNumber) {
		this.touristNumber = touristNumber;
	}
	public int getTouristPassportNo() {
		return touristPassportNo;
	}
	public void setTouristPassportNo(int touristPassportNo) {
		this.touristPassportNo = touristPassportNo;
	}
	public int getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getTouristName() {
		return touristName;
	}
	public void setTouristName(String touristName) {
		this.touristName = touristName;
	}
	public String getTouristAddress() {
		return touristAddress;
	}
	public void setTouristAddress(String touristAddress) {
		this.touristAddress = touristAddress;
	}
	public String getTouristEmail() {
		return touristEmail;
	}
	public void setTouristEmail(String touristEmail) {
		this.touristEmail = touristEmail;
	}
	@Override
	public String toString() {
		return "Tourist [touristId=" + touristId + ", touristNumber=" + touristNumber + ", touristPassportNo="
				+ touristPassportNo + ", cardNumber=" + cardNumber + ", touristName=" + touristName
				+ ", touristAddress=" + touristAddress + ", touristEmail=" + touristEmail + "]";
	}
	
}
