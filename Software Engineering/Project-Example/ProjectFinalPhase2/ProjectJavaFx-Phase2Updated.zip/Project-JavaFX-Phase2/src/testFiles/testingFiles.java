package testFiles;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import MainProject.Tourist;

public class testingFiles {
//public static void main(String [] args) {
//	ArrayList<Tourist> t=new ArrayList<Tourist>();
//	Tourist t1=new Tourist(1,123456,1234,4343243,"Talha","Old airport","talhaqa@gmail.com");
//	Tourist t2=new Tourist(2,213126,1324,1321243,"AbdulRahman","Qatar","abdr@gmail.com");
//	t.add(t1);
//	t.add(t2);
//	saveTourist(t);
//	ReadTest();
//}

public static void saveTourist(  ArrayList<Tourist>  t ) {
		ObjectOutputStream out;
		
		try {
			if(true) {
				
			out = new ObjectOutputStream(new FileOutputStream ("touristDetails.txt"));
			while(t.size()!=0)
			{
							Object o=t.remove(0);
							out.writeObject(o);
			}

			out.close();
		}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.getMessage();

		}catch(EOFException e) {

			System.out.println("EOF Exception: This is the end of the file.");
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}


}
public static void ReadTest (){

ArrayList<Tourist> tourists = new ArrayList<>();
	
		ObjectInputStream in;
		Object obj;

	
			try {
		in = new ObjectInputStream(new FileInputStream("touristDetails.txt"));
	
		while((obj = in.readObject()) != null)
		{
						Tourist t= (Tourist) obj;
						tourists.add(t);
						System.out.println(t);
					}
		
			in.close();
	} catch (FileNotFoundException e) {
	//				// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} catch (IOException | ClassNotFoundException e) {

			System.out.println(	e.getMessage());
			}
			System.out.println(tourists.size() + " tourists read from the file.");
	
			

	}
	
}
