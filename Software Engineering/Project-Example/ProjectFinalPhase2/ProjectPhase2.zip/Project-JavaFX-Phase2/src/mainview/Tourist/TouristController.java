package mainview.Tourist;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import MainProject.Tourist;

import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import MainProject.IssueTouristVisa;

public class TouristController implements Initializable ,TouristInteractionForm {

    @FXML
    private Label bankDecisionLabel;

    @FXML
    private Label creditCardLabel;

    @FXML
    private Label resultNotice;

    @FXML
    private TextField taddress;

    @FXML
    private Button tbutton;

    @FXML
    private TextField tcardnumber;

    @FXML
    private TextField tdecision;

    @FXML
    private TextField temail;

    @FXML
    private TextField tid;

    @FXML
    private TextField tname;

    @FXML
    private TextField tnumber;

    @FXML
    private TextField tpassport;
    
    @FXML
    private Button tbutton1;

   ObservableList<Integer> observableTObjectsID = FXCollections.observableArrayList(TouristRepository.getIds());
   ObservableList<Integer> observableTObjectsPassport=  FXCollections.observableArrayList(TouristRepository.getPassportNumber());
    Tourist t;
 
    
    @FXML
    void handleButtonAction(ActionEvent event) {
    	if(tid.getText()!="" && tname.getText()!="" && tpassport.getText()!="" && tnumber.getText()!="" && temail.getText()!="" && taddress.getText()!="") {
    	t=new Tourist(0,0,0,0,"null","null","null");
    	t.setTouristId(Integer.parseInt(tid.getText()));
    	t.setTouristPassportNo(Integer.parseInt(tpassport.getText()));
    	t.setTouristNumber(Integer.parseInt(tnumber.getText()));
    	t.setTouristName(tname.getText());
    	t.setTouristEmail(temail.getText());
    	t.setTouristAddress(taddress.getText());
    	boolean booleanID=true,booleanPassport=true;
    	if(observableTObjectsID!=null) {
    	for(int i=0; i<observableTObjectsID.size();i++) {
    		if(observableTObjectsID.get(i)==Integer.parseInt(tid.getText()) || observableTObjectsPassport.get(i)==Integer.parseInt(tpassport.getText())) {
    			booleanID=false;
    			booleanPassport=false;
    		}
    	}
    	}
    	if(booleanID==true && booleanPassport==true) {
    	tbutton.setVisible(false);
    	tid.setEditable(false);
    	tpassport.setEditable(false);
    	tnumber.setEditable(false);
    	temail.setEditable(false);
    	taddress.setEditable(false);
    	tname.setEditable(false);
    	tid.setOpacity(0.7);
    	tpassport.setOpacity(0.7);
    	temail.setOpacity(0.7);
    	tnumber.setOpacity(0.7);
    	taddress.setOpacity(0.7);
    	tname.setOpacity(0.7);
    	creditCardLabel.setVisible(true);
    	tcardnumber.setVisible(true);
    	bankDecisionLabel.setVisible(true);
    	tdecision.setVisible(true);
    	tbutton1.setVisible(true);
    	}
    	else {
    		JOptionPane.showMessageDialog(null, "This user already exists");
    	}
    	}
    	else {
    		JOptionPane.showMessageDialog(null, "Missing Information! Try Again Later");
    		Platform.exit();
    	}
    	
    	
    	
    }
    @FXML
    void handleButton2Action(ActionEvent event) {
    	if(tcardnumber.getText()!=""){
    	t.setCardNumber(Integer.parseInt(tcardnumber.getText()));
    	if(tdecision.getText().equalsIgnoreCase("f")) {
    		JOptionPane.showMessageDialog(null, "Bank Decision is Rejected ! Application Rejected !");
    		Platform.exit();
    		
    	}
    	else {
    		
    		addTourist(t);
    		JOptionPane.showMessageDialog(null, "Approved ! Visa Issued "+ "\n\nSummary : \n\n" + "Name of Person : "+tname.getText()+"\nID Number : "+tid.getText()+"\nPassport Number	: "+tpassport.getText()+
    	"\nContact Number  : "+tnumber.getText()+"\nContact Email ID :"+temail.getText()+"\nAddress of Person : "+taddress.getText());
    	}
    	}
    	else {
    		JOptionPane.showMessageDialog(null, "Credit Card Not Found!");
    	}
  
    }
    
    public interface touristInteraction {
    	public void addTourist(Tourist t);
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTourist(Tourist t) {
		TouristRepository.saveTourist(t);
		
	}

}