package testFiles;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Random;

import MainProject.Tourist;

public class testingFiles {
	//For Testing Concurrency
	
//public static void main(String [] args) {
//	ArrayList<Tourist> t=new ArrayList<Tourist>();
//	Random r=new Random();
//	for(int i=0;i<1000;i++) {
//	int id=r.nextInt(10000);
//	Tourist t1=new Tourist(id,123456+id,1234+id,4343243+id,"Talha"+id,"Old airport"+id,"talhaqa@gmail.com"+id);
//	t.add(t1);	
//}
//	saveTourist(t);
//}

public static void saveTourist(  ArrayList<Tourist>  t ) {
		ObjectOutputStream out;
		
		try {
			if(true) {
				
			out = new ObjectOutputStream(new FileOutputStream ("touristDetails.txt"));
			while(t.size()!=0)
			{
							Object o=t.remove(0);
							out.writeObject(o);
			}

			out.close();
		}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.getMessage();

		}catch(EOFException e) {

			System.out.println("EOF Exception: This is the end of the file.");
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}


}
public static void ReadTest (){

ArrayList<Tourist> tourists = new ArrayList<>();
	
		ObjectInputStream in;
		Object obj;

	
			try {
		in = new ObjectInputStream(new FileInputStream("touristDetails.txt"));
	
		while((obj = in.readObject()) != null)
		{
						Tourist t= (Tourist) obj;
						tourists.add(t);
						System.out.println(t);
					}
		
			in.close();
	} catch (FileNotFoundException e) {
	//				// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} catch (IOException | ClassNotFoundException e) {

			System.out.println(	e.getMessage());
			}
			System.out.println(tourists.size() + " tourists read from the file.");
	
			

	}
	
}
