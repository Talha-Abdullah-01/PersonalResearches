package mainview;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainViewController {

	@FXML
	void handleButtonAction(ActionEvent event) {
			FXMLLoader loading = new FXMLLoader(getClass().getResource("Tourist\\touristView.fxml"));
			try {
				AnchorPane pane = (AnchorPane) loading.load();
				Scene scene = new Scene(pane);
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
