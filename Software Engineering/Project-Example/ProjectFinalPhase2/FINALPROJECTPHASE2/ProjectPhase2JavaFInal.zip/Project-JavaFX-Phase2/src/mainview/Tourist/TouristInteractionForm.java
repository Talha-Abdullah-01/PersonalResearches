package mainview.Tourist;

import MainProject.Tourist;

public interface TouristInteractionForm {
	public void addTourist(Tourist t);
}
