package test;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import MainProject.IssueTouristVisa;
import MainProject.Tourist;

class IssueTouristVisaTest {
	
ArrayList<Tourist> tourists = new ArrayList <Tourist>();
	


	IssueTouristVisa issueTouristVisa = new IssueTouristVisa(tourists);
	
	

	@Test
	void testReadTest() {
	assertEquals(tourists,issueTouristVisa.ReadTest()); 
	}



	@Test
	void testFindTourist() {
		assertEquals(null,issueTouristVisa.findTourist(0)); 
	}

	@Test
	void testGetTourists() {
		assertEquals(tourists,issueTouristVisa.getTourists()); 
	}

}
