package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import MainProject.Tourist;



class TouristTest{
	private Tourist tourist = new Tourist (1, 1122, 29800021, 2338899,"Ahmed Saleh",
			"Qatar-Al Sadd", "ahs332@gmail.com");
	@Test
	void testTourist() {
		testGetTouristId();
		testGetTouristNumber();
		testGetTouristPassportNo() ;
		 testGetCardNumber();
		 testGetTouristName() ;
		 testGetTouristAddress() ;
		 testGetTouristEmail() ;
	}

	@Test
	void testGetTouristId() {
		assertEquals(1,tourist.getTouristId(),0);
	}

	@Test
	void testGetTouristNumber() {
		assertEquals(1122,tourist.getTouristNumber(),0);
	}

	@Test
	void testGetTouristPassportNo() {
		assertEquals(29800021,tourist.getTouristPassportNo(),0);
	}

	@Test
	void testGetCardNumber() {
		assertEquals( 2338899,tourist.getCardNumber(),0); 
	}

	@Test
	void testGetTouristName() {
		assertEquals( "Ahmed Saleh",tourist.getTouristName()); 
	}

	@Test
	void testGetTouristAddress() {
		assertEquals( "Qatar-Al Sadd",tourist.getTouristAddress()); 
	}

	@Test
	void testGetTouristEmail() {
		assertEquals( "ahs332@gmail.com",tourist.getTouristEmail()); 
	}

}
