import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EXAMPLE2 extends JFrame {

	private JPanel contentPane;
	private JTextField V1;
	private JTextField V2;
	private JTextField V3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EXAMPLE2 frame = new EXAMPLE2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EXAMPLE2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		V1 = new JTextField();
		V1.setBounds(138, 50, 96, 19);
		contentPane.add(V1);
		V1.setColumns(10);
		
		V2 = new JTextField();
		V2.setEditable(false);
		V2.setBounds(138, 86, 96, 19);
		contentPane.add(V2);
		V2.setColumns(10);
		
		V3 = new JTextField();
		V3.setEditable(false);
		V3.setBounds(138, 125, 96, 19);
		contentPane.add(V3);
		V3.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("DEPTNO");
		lblNewLabel.setBounds(68, 53, 45, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("DNAME");
		lblNewLabel_1.setBounds(68, 89, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("LOC");
		lblNewLabel_2.setBounds(68, 128, 45, 13);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("SEARCH");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				DBoperations dbo;
				try {
					dbo = new DBoperations();
					int dno=Integer.parseInt(V1.getText());
					String dt[]=dbo.getDeptData(dno);
					if(dt[0]==null)
					{
						JOptionPane.showMessageDialog(null,"NO data Found");
					}
					else
					{
						V2.setText(dt[0]);
						V3.setText(dt[1]);
					}
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
			}
		});
		btnNewButton.setBounds(279, 49, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				try {
					DBoperations dbo=new DBoperations();
					dbo.close();
					dispose();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			
			}
		});
		btnNewButton_1.setBounds(279, 85, 85, 21);
		contentPane.add(btnNewButton_1);
	}

}
