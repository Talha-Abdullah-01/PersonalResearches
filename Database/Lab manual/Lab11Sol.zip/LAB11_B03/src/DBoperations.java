import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class DBoperations {
	String server="jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa";
	String user="aws";
	String pass="aws123";
	Connection conn;
	Statement stmt;
	ResultSet rs;
	
	public DBoperations() throws SQLException 
	{
		conn=DriverManager.getConnection(server, user, pass);
		stmt=conn.createStatement();
	}
	
	public void close() throws SQLException
	{
		stmt.close();
		conn.close();
		JOptionPane.showMessageDialog(null, "Close Screen");		
	}
	
	public String[] getDeptData(int dno) throws SQLException
	{
		String result[]=new String[2];
		String sql="select dname,loc from dept where deptno="+dno;
		rs=stmt.executeQuery(sql);
		
		if(rs.next())
		{
			result[0]=rs.getString(1);
			result[1]=rs.getString(2);
		}
		return result;
	}

}
