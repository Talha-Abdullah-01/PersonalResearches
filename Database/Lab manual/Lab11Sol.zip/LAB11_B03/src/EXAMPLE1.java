import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class EXAMPLE1 extends JFrame {

	private JPanel contentPane;
	private JTextField V1;
	private JTextField V2;
	private JTextField V3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EXAMPLE1 frame = new EXAMPLE1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EXAMPLE1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		V1 = new JTextField();
		V1.setBounds(247, 43, 96, 19);
		contentPane.add(V1);
		V1.setColumns(10);
		
		V2 = new JTextField();
		V2.setBounds(247, 86, 96, 19);
		contentPane.add(V2);
		V2.setColumns(10);
		
		V3 = new JTextField();
		V3.setBounds(247, 127, 96, 19);
		contentPane.add(V3);
		V3.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("DEPTNO");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(156, 46, 58, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("DNAME");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(156, 89, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("LOCATION");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(156, 130, 81, 13);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("ENTER");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String server="jdbc:oracle:thin:@coestudb.qu.edu.qa:1521/STUD.qu.edu.qa";
				String user="aws";
				String pass="aws123";
				
				try {
					Connection conn=DriverManager.getConnection(server, user, pass);
					String sql="insert into dept(deptno,dname,loc) values(?,?,?)";
					PreparedStatement stmt=conn.prepareStatement(sql);
					conn.setAutoCommit(false);
					
					stmt.setString(1,V1.getText());
					stmt.setString(2,V2.getText());
					stmt.setString(3,V3.getText());
					
					stmt.executeUpdate();
					int x=JOptionPane.showConfirmDialog(null,"Do you wish to save?","Press Yes or No",JOptionPane.YES_NO_OPTION);
					if(x==JOptionPane.YES_OPTION)
					{
						conn.setAutoCommit(true);
						JOptionPane.showMessageDialog(null, "Transactin Saved Successfully");
					}
					else
					{
						conn.setAutoCommit(false);
						JOptionPane.showMessageDialog(null, "Transactin Aborted");
					}
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(156, 181, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("EXIT");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(null,"Closing the Screen");
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(270, 181, 85, 21);
		contentPane.add(btnNewButton_1);
	}

}
