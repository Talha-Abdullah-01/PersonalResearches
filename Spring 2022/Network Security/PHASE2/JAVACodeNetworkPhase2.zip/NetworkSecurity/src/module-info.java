module NetworkSecurity {
	requires java.desktop;
	requires java.xml;
}