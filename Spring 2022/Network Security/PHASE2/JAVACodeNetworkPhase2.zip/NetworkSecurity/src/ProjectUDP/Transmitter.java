package ProjectUDP;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;

public class Transmitter extends Thread{

	public static void main (String [] args) {
		try{
			DatagramSocket Transmitter= new DatagramSocket();
			
			byte[] buf=new byte[65000];
			System.out.println("Transmitting the image...");
			Path fileName = Path.of("ErrorBinary.docx");
			String file_content = Files.readString(fileName);
			String message=file_content;
			System.out.println("this is message length : " +message.length());
			int n=message.length();
			String[] messages=message.split(" ");
			messages=message.split(" ");
			System.out.println("This is messages length : "+messages.length);
			
			//
			StringBuffer sb = new StringBuffer();
		      for(int i = 0; i < messages.length; i++) {
		         sb.append(messages[i]+" ");
		      }
		      String str = sb.toString();
		      System.out.println(str);
			
			//
			int i=0;
			String buf1=str.substring(0,str.length()/2);
			String buf2=str.substring(str.length()/2,str.length());
			String [] array=new String[] {buf1,buf2};
			while(i==0 || i==1) {
				buf = array[i].getBytes();
				System.out.println(buf.length);
				DatagramPacket packets = new DatagramPacket(buf, buf.length,InetAddress.getByName("127.0.0.1"), 3000);
				Transmitter.send(packets);
				i++;
			}
			Transmitter.close();
		}
		catch(Exception e) {

		}
	}
	
}
