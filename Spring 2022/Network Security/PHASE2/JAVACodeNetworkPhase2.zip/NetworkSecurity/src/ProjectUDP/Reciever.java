package ProjectUDP;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

import javax.imageio.ImageIO;

public class Reciever extends Thread{
public static void main(String[] args) throws IOException {
	String FinalMessage="";
	DatagramSocket Reciever=new DatagramSocket(3000);
	System.out.println("Ready to recieve the Image..");
	System.out.println("Waiting for Packets");
	boolean running=true;
	while(running) {
		byte buf[]=new byte[65000];
		DatagramPacket packets = new DatagramPacket(buf, buf.length,InetAddress.getByName("127.0.0.1"),3000);
		Reciever.receive(packets);
	    String message = new String(packets.getData(), 0, packets.getLength());
	    System.out.println();
	    //System.out.println(message);
		FinalMessage+=message+"";
		System.out.println(FinalMessage.length());
		if(FinalMessage.length()>69451) {
			running=false;
			System.out.println("Recieved");
			continue;
		}
		System.out.println(FinalMessage.length());
	}
	Reciever.close();
	System.out.println(FinalMessage);
	String [] messages=FinalMessage.split(" ");
	byte[] wantedBytes=new byte[messages.length];
	for(int i=0;i<messages.length;i++) {
		wantedBytes[i]=convertToByte(messages[i]);
		System.out.print(wantedBytes[i]+",");
	}
	 System.out.println(wantedBytes.length);
//	 String encoded=Base64.getEncoder().encodeToString(wantedBytes);
//	 System.out.println(encoded.length());
//	 Path fileName1 = Path.of("Base64String.docx");
//	 Files.writeString(fileName1, encoded);
	 ByteArrayInputStream bis = new ByteArrayInputStream(wantedBytes);
     BufferedImage bImage2 = ImageIO.read(bis);
     ImageIO.write(bImage2, "jpg", new File("output5.jpg") );
     System.out.println("Image created");

   }
public static byte convertToByte(String str) {
//   if(str.length()==9) {
//   	str=str.substring(0,str.length()-1);
//   }
	if(str.charAt(0) == '1') {
        str = str.substring(1);
        str = "-0" + str;
    }
    byte b = Byte.parseByte(str, 2);
    return b;
}	
}
