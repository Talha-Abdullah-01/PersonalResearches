package ProjectUDP;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

import javax.imageio.ImageIO;
public class ImageBinary {
	public static byte[] extractBytes (String ImageName) throws IOException {
		File fnew=new File("E:\\Javanewoutputs\\NetworkSecurity\\src\\qatar-flag-260nw-107328506.jpg");
		BufferedImage originalImage=ImageIO.read(fnew);
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		ImageIO.write(originalImage, "jpg", baos );
		byte[] imageInByte=baos.toByteArray();
		return imageInByte;
	}

	public static void main(String [] args) throws IOException {

		try {
			byte[] bytesFromFile;
			bytesFromFile = extractBytes("Image");
//			String encoded = Base64.getEncoder().encodeToString(bytesFromFile);
			for (int i=0;i<bytesFromFile.length;i++) {
				System.out.print(bytesFromFile[i]+",");
			}
			String[] array=new String[bytesFromFile.length];
			for(int i=0;i<bytesFromFile.length;i++) {
				array[i]=convertToBit(bytesFromFile[i]);
//				System.out.print(array[i]+",");
			}
			System.out.println();
			String resulted=String.join(" ",array);
			Path fileName = Path.of("imageBinary.docx");
			Files.writeString(fileName, resulted);
			System.out.println(resulted.length());
			
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	public static String convertToBit(Byte b) {
		StringBuilder str=new StringBuilder();
		if(b<0) {
	        str.append(1);
	        b=(byte) -b;
	    }
	    else {
	    	str.append(0);
	    }
	    str.append(String.format("%7s", Integer.toBinaryString(b & 0xFF)).replace(' ', '0'));
	    return str.toString();
	}	
}