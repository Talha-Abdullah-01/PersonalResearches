package ProjectUDP;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ErrorDealer {
	public static void main(String [] args) throws IOException {
	Path fileName = Path.of("imageBinary.docx");
	String file_content = Files.readString(fileName);
	String message=file_content;
	System.out.println("this is message length : " +message.length());
	int n=message.length();
	String[] messages=new String[n/8+1];
	messages=message.split(" ");

	//Inducing Errors 
	List<Integer> ErrorPercentage=new ArrayList<>();
	ErrorPercentage.add(1);
	ErrorPercentage.add(2);
	ErrorPercentage.add(3);
	Random rand = new Random();
    int errorOfUDP=ErrorPercentage.get(rand.nextInt(ErrorPercentage.size()));
	System.out.println("Error of UDP Server is :"+errorOfUDP+"%");
	System.out.println("Messages length is : "+messages.length);
	int k=0;
	int m=0;
	for(int i=0;i<messages.length;i++) {
		if(m%10==0) {
		System.out.println(k++);
//		if(messages[i].length()==9) {
//			messages[i]=messages[i].substring(0,messages[i].length()-1);
//			System.out.println("For 9 : "+messages[i]);
//			continue;
//		}
		if(messages[i].length()==9) {
			continue;
		}
		char[] splitedMessage=new char[messages[i].length()];
		splitedMessage=messages[i].toCharArray();
		Random random=new Random();
		for(int j=0;j<errorOfUDP;j++) {
		int min = 0;
		int max = 8;
		int value=0;
		boolean check=true;
		while(check) {
		value = random.nextInt(max + min) + min;
		break;
			}
		if(splitedMessage[value]==1){
			splitedMessage[value]='0';
		}
		else {
			splitedMessage[value]='1';
		}
		}
		messages[i]=String.valueOf(splitedMessage);
		}
		m++;
		}
	String resulted=String.join(" ",messages);
	Path fileName1 = Path.of("ErrorBinary.docx");
	Files.writeString(fileName1, resulted);
	System.out.println(resulted.length());
	
	}
}
