package ProjectUDP;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class tester {
	    public static byte convertToByte(String str) {
	        if(str.charAt(0) == '1') {
	            str = str.substring(1);
	            str = "-0" + str;
	        }
	        byte b = Byte.parseByte(str, 2);
	        return b;
	    }
	    public static void main(String args[]) throws IOException {
	    	Path fileName = Path.of("ErrorBinary.docx");
			String file_content = Files.readString(fileName);
			String message=file_content;
			System.out.println("this is message length : " +message.length());
	        //String str = "010010110";
	        //byte b = convertToByte(str);
	        //System.out.println(b);
	    }
}
