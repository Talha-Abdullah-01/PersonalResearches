package Assignment1;
import java.util.Scanner;
public class LargeNumberArray {
public static void main(String []args) {
	Scanner writer=new Scanner(System.in);
	System.out.print("Enter the Size of the Array : ");
	int size=writer.nextInt();
	System.out.println("Size of the array is : "+size);
	int[] arr=new int[size];
	System.out.println("Enter Array Elements :");
	for(int i=0; i<size;i++) {
		System.out.print(i+"th index : ");
		int n=writer.nextInt();
		arr[i]=n;
	}
	int max=arr[0];
	for(int i=1;i<size;i++) {
		if(max<arr[i]) {
			max=arr[i];
		}
	}
	System.out.println("Max Number in Array is : "+max);
}
}
