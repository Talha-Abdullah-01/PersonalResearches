package Assignment1;

import java.util.ArrayList;
import java.util.Scanner;

public class smallNumbers {
public static void main(String [] args) {
	Scanner write=new Scanner(System.in);
	System.out.print("Enter the Size of the List : ");
	int n=write.nextInt();
	System.out.println("Enter the List values : ");
	ArrayList<Integer> array=new ArrayList<>();
	ArrayList<Integer> array2=new ArrayList<>();
	for(int i=0;i<n;i++) {
		System.out.print(i+"th index = ");
		int k=write.nextInt();
		array.add(k);
	}
	System.out.print("Enter the number of smallest numbers :");
	int smalls=write.nextInt();
	int index=0;
	for(int i=0;i<smalls;i++) {
		int min=array.get(0);
		for(int j=0;j<array.size();j++) {
			if (min>array.get(j)) {
				min=array.get(j);
				index=j;
			}
		}
		array.remove(index);
		array2.add(min);
	}
	System.out.println("Smallest Numbers in the list are: ");
	for(int i=0;i<smalls;i++) {
		System.out.print(array2.get(i)+" ");
}
}
}
