package Assignment3;

public class Algorithm3_1 {
public static void main(String [] args) {
	//int n=7; int k=2;
	int n=100; int k=5;
	System.out.println("ALGORITHM 3.1");
	long start=System.nanoTime();
	int answer=binomialCoefficient(n,k);
	long end=System.nanoTime();
	System.out.println("n=100,k=5, Answer :"+answer);
	long performance=end-start;
	System.out.println("Time taken by this algorithm is : "+performance);
}

private static int binomialCoefficient(int n, int k) {
	// TODO Auto-generated method stub
	if(k>n)
		return 0;
	if (k==0 || k==n)
		return 1;
	return binomialCoefficient(n-1,k-1)+binomialCoefficient(n-1,k);
}

}
