package Assignment3;

public class Algorithm3_2 {
public static void main(String [] args) {
	//int n=7; int k=2;
	int n=100; int k=5;
	System.out.println("ALGORITHM 3.2");
	long start=System.nanoTime();
	int ans=binomialCoefficient(n,k);
	long end=System.nanoTime();
	System.out.println("Answer is : "+ans);
	long performance=end-start;
	System.out.println("Time taken by this algorithm is : "+performance);
}

private static int binomialCoefficient(int n, int k) {
	// TODO Auto-generated method stub
	int A[][]=new int[n+1][k+1];
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=Math.min(i,k);j++)
		{
		if(j==0 || j==i)
			A[i][j]=1;
		else
			A[i][j]=A[i-1][j-1]+A[i-1][j];
		}
	return A[n][k];
}


}
