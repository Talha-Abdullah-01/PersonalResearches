package Assignment3;

public class PrimsAlgo {
	public static void main(String []args) {
		int graph[][]=new int[][]{ {0,3,0,3,0},
			{4,0,4,5,3},
			{2,4,0,4,0},
			{5,0,3,4,1},
			{2,0,0,4,1}};
			prim(graph);
	}
	
	
	private static final int A=5;
	public static int mkey(int key[], boolean msSet[])
	{
		int min=Integer.MAX_VALUE, min_index=-1;
		for (int i=0;i<A;i++) {
			if(msSet[i]==false && key[i]<min) {
				min=key[i];
				min_index=i;
			}
		}
		return min_index;
	}
	public static void prim(int graph[][]) {
		int p[]= new int[A];
		int k[]= new int[A];
		boolean msSet[]=new boolean[A];
		for (int j=0;j<A;j++) {
			k[j]=Integer.MAX_VALUE;
			msSet[j]=false;
		}
		k[0]=0;
		p[0]=-1;
		for(int c=0;c<A-1;c++) {
			int u=mkey(k,msSet);
			msSet[u]=true;
			for(int a=0;a<A;a++) {
				if(graph[u][a]!=0 && msSet[a]==false && graph[u][a]<k[a]) {
					p[a]=u;
					k[a]=graph[u][a];
				}
			}
		}
		printPrim(p,graph);
	}
	public static void printPrim(int p[], int g[][]) {
		System.out.println("Edge	Weight");
		for(int i=1;i<A;i++) {
			System.out.println(p[i]+" to "+i+" :	"+g[i][p[i]]);
		}
	}
}
