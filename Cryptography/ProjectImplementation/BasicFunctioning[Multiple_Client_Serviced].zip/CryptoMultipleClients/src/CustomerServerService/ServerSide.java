package CustomerServerService;
import java.net.*;
import java.io.*;

public class ServerSide {
	public static void main(String[] args) {
		ServerSocket server = null;
		Socket nextClient = null;
		try {
			server = new ServerSocket(1500);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		System.out.println("Server waiting for client on port " + server.getLocalPort());
		System.out.println("Password Storage System Server Started");
		try {
			for (;;) {
				try {
					nextClient = server.accept();
				} catch (IOException e) {
					e.printStackTrace();
				}
				//pass the initialized/started ports to the main Service Class
				MainService s = new MainService(nextClient);
				s.start();
			}
		} finally {
			try {
				if (server != null)
					server.close();
				if (nextClient != null)
					nextClient.close();
				
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}