package CustomerServerService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.TimeUnit;


public class CustomerSide {
	public CustomerSide() {
		try {
			int n=0;
			//Customer connection to the server with port 1500
			Socket clientconn = new Socket("localhost", 1500);
			BufferedReader from_server = new BufferedReader(new InputStreamReader(clientconn.getInputStream()));
			BufferedReader from_client = new BufferedReader(new InputStreamReader(System.in));
			PrintWriter to_server = new PrintWriter(clientconn.getOutputStream(),true);
			//Print the connection status with the server
			System.out.println("Connected with server " + clientconn.getInetAddress() + ":" + clientconn.getPort());
			while(true) {
			String reader;
			reader=from_server.readLine();
			System.out.println(reader);
			reader=from_server.readLine();
			System.out.print(reader);
			String username=from_client.readLine();
			reader=from_server.readLine();
			System.out.print(reader);
			String password=from_client.readLine();
			String data=username+","+password;
			to_server.println(data);
			System.out.println("Verifying....");
			reader=from_server.readLine();
			if(reader.equals("User Verified!")) {
				System.out.println(reader);
				for(int i=0;i<3;i++) {
					reader=from_server.readLine();
					System.out.println(reader);
				}
				System.out.println("-------------------TERMINATING----------------");
				System.exit(0);
			}
			else {
				System.out.println("User is Not Registered!");
				n++;
				if(n>2) {
					System.out.println("Your Have Failed to Enter Correct Password 3 Times");
					try {
						System.out.println("Wait 3 minutes before you try Again!");
					    TimeUnit.SECONDS.sleep(180);
					} catch (InterruptedException ie) {
					    Thread.currentThread().interrupt();
					}
				}
			}
			
		}
		} catch (IOException ioe) {
			System.out.println("Error" + ioe);
		}

	}

	public static void main(String [] args) {
		new CustomerSide();
	}

}
