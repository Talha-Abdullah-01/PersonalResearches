package CustomerServerService;

import java.util.ArrayList;

public class customerDataBase {
private String username;
private String password;
private ArrayList<ActualPasswords> passwordList;
public customerDataBase(String username, String password, ArrayList<ActualPasswords> passwordList) {
	super();
	this.username = username;
	this.password = password;
	this.passwordList = passwordList;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public ArrayList<ActualPasswords> getPasswordList() {
	return passwordList;
}
public void setPasswordList(ArrayList<ActualPasswords> passwordList) {
	this.passwordList = passwordList;
}
@Override
public String toString() {
	return "customerDataBase [username=" + username + ", password=" + password + ", passwordList=" + passwordList + "]";
}


}
