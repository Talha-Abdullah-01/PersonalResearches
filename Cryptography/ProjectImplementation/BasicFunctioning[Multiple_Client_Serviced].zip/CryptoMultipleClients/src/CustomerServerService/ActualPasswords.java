package CustomerServerService;

public class ActualPasswords {
private String entity;
private String password;
public ActualPasswords(String entity, String password) {
	super();
	this.entity = entity;
	this.password = password;
}
public String getEntity() {
	return entity;
}
public void setEntity(String entity) {
	this.entity = entity;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "ActualPasswords [entity=" + entity + ", password=" + password + "]";
}

}
