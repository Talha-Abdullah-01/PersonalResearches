package CustomerServerService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MainService extends Thread {
	Socket nextClient;
	PrintWriter to_client;
	BufferedReader from_client;
	ServerSocket server;

	public MainService(Socket nextClient) {
		super();
		this.nextClient = nextClient;
	}

	public void run() {
		try {
			
			//Assumed Database for Customer Login [ assumed that these users have signed up to the service ]
			ArrayList <customerDataBase> customerLogInfo=new ArrayList<>();
			ArrayList <ActualPasswords> passwordLogInfo1=new ArrayList<>();
			ArrayList <ActualPasswords> passwordLogInfo2=new ArrayList<>();
			ArrayList <ActualPasswords> passwordLogInfo3=new ArrayList<>();
			ActualPasswords p1=new ActualPasswords("www.google.com", "LoveHealth");
			ActualPasswords p2=new ActualPasswords("www.github.com", "Lovegit123");
			passwordLogInfo1.add(p1);
			passwordLogInfo1.add(p2);
			customerDataBase c1=new customerDataBase("Talha", "Talha123", passwordLogInfo1);
			ActualPasswords p3=new ActualPasswords("www.google.com", "HateHealth");
			ActualPasswords p4=new ActualPasswords("www.github.com", "Github234");
			passwordLogInfo2.add(p3);
			passwordLogInfo2.add(p4);
			customerDataBase c2=new customerDataBase("Omar","omar123", passwordLogInfo2);
			ActualPasswords p5=new ActualPasswords("www.google.com", "34242342");
			ActualPasswords p6=new ActualPasswords("www.github.com", "54644567");
			passwordLogInfo3.add(p5);
			passwordLogInfo3.add(p6);
			customerDataBase c3=new customerDataBase("Ibrahim","ibrahim123", passwordLogInfo3);
			customerLogInfo.add(c1);
			customerLogInfo.add(c2);
			customerLogInfo.add(c3);
			
	
			to_client = new PrintWriter(nextClient.getOutputStream(), true);
			from_client = new BufferedReader(new InputStreamReader(nextClient.getInputStream()));
			// Display connection details
			System.out.println("Receiving Request From " + nextClient.getInetAddress() + ":" + nextClient.getPort());
			while(true) {
			to_client.println("<------------Login To the System--------->");
			to_client.println("Enter your username :");
			to_client.println("Enter your password :");
			String clientData = from_client.readLine();
			System.out.println("Recieved Data is : "+clientData+ "[ From Client IP : "+nextClient.getInetAddress()+nextClient.getPort()+" ]");
			String [] tokenizedData=clientData.split("[,]", 0);
			//System.out.println("Username : "+ tokenizedData[0]);
			//System.out.println("Password : "+ tokenizedData[1]);
			int z=0;
			int k=0;
			for(int i=0;i<3;i++) {
				String user=customerLogInfo.get(i).getUsername();
				String password=customerLogInfo.get(i).getPassword();
				if(tokenizedData[0].trim().equals(user.trim()) && tokenizedData[1].trim().equals(password.trim())) {
					z=1;
					k=1;
					to_client.println("User Verified!");
					//System.out.println("Verified");
					ArrayList<ActualPasswords> data=new ArrayList<>();
					data=customerLogInfo.get(i).getPasswordList();
					to_client.println("<------Displaying All Your Passwords----->");
					for(int j=0;j<data.size();j++) {
						to_client.println(data.get(j).getEntity()+"  :  "+data.get(j).getPassword());
					}
					break;
				}
			
			}
			if(k==1) {
				break;
			}
			if(z==0) {
				to_client.println("User Verification Failed !");
			}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}