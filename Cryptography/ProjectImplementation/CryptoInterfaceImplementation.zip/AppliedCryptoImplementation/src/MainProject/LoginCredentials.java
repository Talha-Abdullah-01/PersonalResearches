package MainProject;

import java.io.Serializable;

public class LoginCredentials implements Serializable{
	private static final long serialVersionUID = 6894463765965627542L;
	private String loginName, password;
	public LoginCredentials(String loginName, String password) {
		super();
		this.loginName = loginName;
		this.password = password;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginCredentials [loginName=" + loginName + ", password=" + password + "]";
	}
	
	
	
}
