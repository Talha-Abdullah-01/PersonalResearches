package DataBaseEncryption;

public class MainDataBase {
	//Assumed Database for Customer Login [ assumed that these users have signed up to the service ]
	//sample values for user1 only taken for example purpose
	private String user1entity1="www.google.com";
	private String user1password1="2324324";
	private String user1entity2="www.github.com";
	private String user1password2="21312541";
	public String getUser1entity1() {
		return user1entity1;
	}
	public String getUser1password1() {
		return user1password1;
	}
	public String getUser1entity2() {
		return user1entity2;
	}
	public String getUser1password2() {
		return user1password2;
	}
}
