package DataBaseEncryption;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


public class EncryptingDatabase {
public static void main(String [] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
	String FilePath=System.getProperty("user.dir");
	System.out.println("Current Directory : "+FilePath);
	MainDataBase MDB=new MainDataBase();
	//Creating a Signature object
    Signature sign = Signature.getInstance("SHA256withRSA");
    //Creating KeyPair generator object
    KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
    keyPairGen.initialize(2048);
    KeyPair pair = keyPairGen.generateKeyPair();      
    //Creating a Cipher object
    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    cipher.init(Cipher.ENCRYPT_MODE, pair.getPublic());  
    byte[] input = MDB.getUser1entity1().getBytes();	  
    cipher.update(input);
    //encrypting the data
    byte[] cipherText = cipher.doFinal();	
    System.out.println("Encrypted Data (User1Entity1):");
    System.out.println(new String(cipherText, "UTF8"));
    System.out.println();
    Cipher cipher1 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    cipher1.init(Cipher.ENCRYPT_MODE, pair.getPublic()); 
    byte[] input1 = MDB.getUser1password1().getBytes();	  
    cipher1.update(input1);
    //encrypting the data
    byte[] cipherText1 = cipher1.doFinal();	
    System.out.println("Encrypted Data (User1Password1):");
    System.out.println(new String(cipherText1, "UTF8"));
    System.out.println();
    Cipher cipher2 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    cipher2.init(Cipher.ENCRYPT_MODE, pair.getPublic()); 
    byte[] input2 = MDB.getUser1entity2().getBytes();	  
    cipher2.update(input2);
    //encrypting the data
    byte[] cipherText2 = cipher2.doFinal();	
    System.out.println("Encrypted Data (User1Entity2):");
    System.out.println(new String(cipherText2, "UTF8"));
    System.out.println();
    Cipher cipher3 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    cipher3.init(Cipher.ENCRYPT_MODE, pair.getPublic()); 
    byte[] input3 = MDB.getUser1password2().getBytes();	  
    cipher.update(input3);
    //encrypting the data
    byte[] cipherText3 = cipher3.doFinal();	
    System.out.println("Encrypted Data (User1Password2):");
    System.out.println(new String(cipherText3, "UTF8"));
 }
}

