package Hashing;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class HashFunction {
	//using MD5 Hashing
	public static void main (String [] args) {

		ArrayList <String> hashedDataValues=new ArrayList<>();
		LoginData l1=new LoginData("Talha", "Talha123");
		LoginData l2=new LoginData("Ibrahim", "ibrahim123");
		LoginData l3=new LoginData("Omar", "omar123");
		ArrayList <LoginData> data=new ArrayList<>();
		data.add(l1);
		data.add(l2);
		data.add(l3);
		String [] hashDatabase=new String[3];
		for(int i=0;i<data.size();i++) {
			hashDatabase[i]=data.get(i).getUsername()+","+data.get(i).getPassword();
		}
		String dataToHash= "Talha,Talha123";
		String generatedHash="null";
		try {
			for(int i=0;i<hashDatabase.length;i++) {
			MessageDigest hash=MessageDigest.getInstance("MD5");
			hash.update(hashDatabase[i].getBytes());
			byte[] b=hash.digest();
			StringBuilder sb = new StringBuilder();
			//this byte contains decimal format to be converted to hexadecimal format
		      for (int j = 0; j < b.length; j++) {
		        sb.append(Integer.toString((b[j] & 0xff) + 0x100, 16).substring(1));
		      }
		      hashedDataValues.add(sb.toString());
			}
			System.out.println("The Hashed Database Values Will be Hidden from the User (HIDDEN FROM USER): ");
			for(int i=0;i<hashDatabase.length;i++) {
				System.out.println(hashedDataValues.get(i));
			}
			System.out.println();
			System.out.println("To check if the Entered/The one who logged in is a legitimate user");
			MessageDigest checkHash=MessageDigest.getInstance("MD5");
			checkHash.update(dataToHash.getBytes());
			byte[]b=checkHash.digest();
			StringBuilder s=new StringBuilder();
			for (int i = 0; i < b.length; i++) {
		        s.append(Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1));
		      }
			generatedHash=s.toString();
			for(int i=0; i<hashedDataValues.size();i++) {
				if(generatedHash.equals(hashedDataValues.get(i))) {
					System.out.println("The Hashes Match and the User is Verified!");
					System.exit(0);
				}
			}
			System.out.println("The Hash Does not Match");
		}catch(NoSuchAlgorithmException E) {
			E.printStackTrace();
		}
	}
}
